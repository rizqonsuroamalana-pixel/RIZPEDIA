# Tutorial Setup Payment Gateway (Tripay)

Dokumen ini isinya cuma satu hal: **cara Anda sendiri mengisi kredensial payment gateway**
supaya alur di bawah ini beneran jalan (bukan simulasi lagi):

```
User pilih produk
   → Backend membuat Order       (POST /api/orders)
   → Backend membuat Payment      (POST /api/payments)   ← panggil Tripay di sini
   → Payment Gateway
   → User membayar
   → Gateway → Webhook Rizpedia   (POST /api/payments/webhook)
   → Verifikasi signature
   → paymentStatus = PAID
   → Topup ke Provider            (utils/topup.js — provider game, beda tutorial)
   → Provider response
   → topupStatus = SUCCESS
   → Notifikasi user
```

Kode untuk 2 kotak yang di-bold di atas **sudah saya buatkan** (`routes/payments.js` +
`utils/tripay.js`). Yang perlu Anda lakukan cuma isi 4 nilai di `.env`. Saya pilih **Tripay**
karena paling umum dipakai untuk situs top up voucher game di Indonesia (dukung QRIS, VA semua
bank, Alfamart/Indomaret, dll dalam satu akun) — kalau Anda mau pakai Midtrans/Xendit, alurnya
mirip, tinggal bilang nanti saya sesuaikan `utils/tripay.js`-nya jadi `utils/midtrans.js` dsb.

---

## Langkah 1 — Daftar akun Tripay

1. Buka **tripay.co.id** → Daftar.
2. Lengkapi profil merchant (nama usaha, rekening bank untuk pencairan dana, dll).
3. Upload dokumen verifikasi yang diminta (biasanya KTP + foto produk/website). Proses
   verifikasi manual oleh tim Tripay, biasanya 1x24 jam kerja.
4. **Sambil menunggu verifikasi, Anda tetap bisa coba di mode Sandbox** — tidak perlu
   menunggu approve untuk development.

## Langkah 2 — Ambil kredensial

Setelah login ke dashboard Tripay:

1. Masuk ke menu **Merchant → Sandbox** (untuk uji coba) atau **Merchant → Production**
   (setelah akun disetujui).
2. Catat 3 nilai ini:
   - **Kode Merchant** (`Merchant Code`) — contoh: `T12345`
   - **API Key**
   - **Private Key**

   ⚠️ **Private Key jangan pernah dibagikan ke siapa pun / di-commit ke GitHub** — ini yang
   dipakai untuk tanda tangan digital semua transaksi Anda.

3. Sandbox dan Production punya kredensial **yang berbeda** — jangan tertukar.

## Langkah 3 — Isi ke file `.env`

Buka `backend/.env` (kalau belum ada, copy dari `.env.example` dulu), isi bagian ini:

```env
PAYMENT_PROVIDER=tripay
TRIPAY_MODE=sandbox
TRIPAY_MERCHANT_CODE=T12345
TRIPAY_API_KEY=isi_api_key_dari_dashboard
TRIPAY_PRIVATE_KEY=isi_private_key_dari_dashboard

APP_BASE_URL=https://xxxxx.ngrok-free.app
```

Penjelasan tiap baris:
- `PAYMENT_PROVIDER=tripay` → mengaktifkan integrasi Tripay sungguhan (default sebelumnya
  `manual` = dummy, buat testing UI tanpa akun Tripay).
- `TRIPAY_MODE=sandbox` → pakai dulu terus sampai yakin alurnya benar. Ganti ke
  `production` kalau sudah siap terima uang asli.
- `APP_BASE_URL` → **wajib URL publik**, bukan `localhost`. Tripay mengirim webhook dari
  server mereka ke server Anda, jadi `localhost` tidak akan pernah bisa diakses dari luar.
  - Kalau develop di laptop: pakai **ngrok** (`ngrok http 3000`), copy URL `https://xxxx.ngrok-free.app`
    yang muncul, tempel ke sini.
  - Kalau sudah deploy (Railway/Render/VPS): isi domain aslinya, mis. `https://rizpedia.com`.

## Langkah 4 — Daftarkan Callback URL di dashboard Tripay

1. Di dashboard Tripay → menu **Merchant → Pengaturan** (atau "Callback URL").
2. Isi kolom **Callback/Webhook URL** dengan:
   ```
   {APP_BASE_URL}/api/payments/webhook
   ```
   Contoh: `https://xxxx.ngrok-free.app/api/payments/webhook`
3. Simpan. Ini yang membuat Tripay tahu ke mana harus mengirim notifikasi setelah user bayar.

## Langkah 5 — Cek daftar metode pembayaran yang aktif

`paymentMethod` yang dikirim ke `POST /api/payments` harus persis sama dengan kode channel
Tripay, misalnya `QRIS`, `BRIVA` (VA BRI), `BCAVA` (VA BCA), `ALFAMART`, dst.

Cara lihat channel yang aktif di akun Anda: dashboard Tripay → menu **Kanal Pembayaran**,
atau lewat API:
```
GET https://tripay.co.id/api-sandbox/merchant/payment-channel
Authorization: Bearer <TRIPAY_API_KEY>
```

## Langkah 6 — Restart & coba

```
cd backend
npm install
npm start
```

Alur test manual:
1. Login dulu lewat `POST /api/auth/login` → dapat `token`.
2. `POST /api/orders` dengan `productId` & `targetId` valid → dapat `order.id`.
3. `POST /api/payments` dengan `{ "orderId": "...", "paymentMethod": "QRIS" }` (pakai header
   `Authorization: Bearer <token>`) → responsnya berisi `instructions.qrUrl` / `payCode` yang
   bisa ditampilkan ke user.
4. Di **Sandbox**, Tripay biasanya punya tombol simulasi "Bayar" di dashboard transaksinya
   supaya Anda tidak perlu transfer uang asli untuk testing.
5. Setelah disimulasikan lunas, Tripay otomatis memanggil
   `POST {APP_BASE_URL}/api/payments/webhook` → cek log server: `paymentStatus` order
   tadi harus berubah jadi `paid`, RizPoint bertambah, dan notifikasi baru muncul di
   `GET /api/notifications`.

## Kalau mau tetap pakai mode manual dulu (belum ada akun Tripay)

Biarkan saja `PAYMENT_PROVIDER=manual` di `.env` (nilai default). Alurnya tetap jalan penuh,
cuma langkah "bayar ke gateway"-nya diganti Anda memanggil webhook secara manual untuk simulasi:

```
POST /api/payments/webhook
Header: x-webhook-secret: <isi sama dengan PAYMENT_WEBHOOK_SECRET di .env>
Body: { "paymentReference": "PAY-XXXXXXXXXX", "status": "paid" }
```//
(`paymentReference`-nya ambil dari respons `POST /api/payments` sebelumnya)

## Pindah ke Production

1. Pastikan akun Tripay sudah **disetujui/verified**.
2. Ambil kredensial dari tab **Production** (bukan Sandbox) di dashboard.
3. Ganti di `.env`:
   ```env
   TRIPAY_MODE=production
   TRIPAY_MERCHANT_CODE=... (yang production)
   TRIPAY_API_KEY=... (yang production)
   TRIPAY_PRIVATE_KEY=... (yang production)
   APP_BASE_URL=https://domain-asli-kamu.com
   ```
4. Daftarkan ulang Callback URL production di dashboard (poin sama seperti Langkah 4).
5. Deploy ulang, lalu coba transaksi kecil dengan uang asli untuk memastikan semuanya benar
   sebelum dibuka ke publik.
