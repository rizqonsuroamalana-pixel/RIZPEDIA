const express = require('express');
const prisma = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { settleOrderPayment } = require('../utils/settleOrderPayment');
const digiflazz = require('../utils/digiflazz');

const router = express.Router();

// Semua route di file ini WAJIB login DULU (requireAuth) baru dicek role-nya (requireAdmin).
// Urutan middleware penting: requireAdmin baca req.user yang cuma di-set oleh requireAuth.
router.use(requireAuth, requireAdmin);

// Helper: catat aksi admin ke tabel admin_logs (audit trail) — dipakai di semua endpoint
// yang MENGUBAH data (create/update), bukan yang cuma GET/monitoring.
async function logAdminAction(req, action, description) {
  await prisma.adminLog.create({
    data: { adminId: req.user.id, action, description, ipAddress: req.ip },
  });
}

// ============================================================
// 33. DASHBOARD — ringkasan angka buat halaman utama admin
// ============================================================
router.get(
  '/dashboard',
  asyncHandler(async (req, res) => {
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);

    const [
      totalUsers,
      totalOrders,
      ordersToday,
      revenueAgg,
      revenueTodayAgg,
      pendingPayments,
      unfinishedTopups,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.order.count(),
      prisma.order.count({ where: { createdAt: { gte: startOfToday } } }),
      prisma.order.aggregate({ where: { paymentStatus: 'paid' }, _sum: { amount: true } }),
      prisma.order.aggregate({
        where: { paymentStatus: 'paid', createdAt: { gte: startOfToday } },
        _sum: { amount: true },
      }),
      prisma.order.count({ where: { paymentStatus: 'pending' } }),
      prisma.order.count({
        where: { paymentStatus: 'paid', topupStatus: { in: ['pending', 'processing', 'failed'] } },
      }),
    ]);

    res.json({
      totalUsers,
      totalOrders,
      ordersToday,
      totalRevenue: Number(revenueAgg._sum.amount || 0),
      revenueToday: Number(revenueTodayAgg._sum.amount || 0),
      pendingPayments,
      unfinishedTopups, // sudah dibayar tapi topup-nya belum sukses (perlu perhatian admin)
    });
  })
);

// ============================================================
// 34. KELOLA GAME
// ============================================================
router.get(
  '/games',
  asyncHandler(async (req, res) => {
    const games = await prisma.game.findMany({ orderBy: { createdAt: 'desc' } });
    res.json(games);
  })
);

router.post(
  '/games',
  asyncHandler(async (req, res) => {
    const { name, slug, image } = req.body || {};
    if (!name || !slug) return res.status(400).json({ error: 'name dan slug wajib diisi.' });

    const existing = await prisma.game.findUnique({ where: { slug } });
    if (existing) return res.status(409).json({ error: 'Slug game sudah dipakai.' });

    const game = await prisma.game.create({ data: { name, slug, image: image || null } });
    await logAdminAction(req, 'create_game', `Membuat game "${name}" (${slug})`);
    res.status(201).json(game);
  })
);

router.patch(
  '/games/:id',
  asyncHandler(async (req, res) => {
    const existing = await prisma.game.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: 'Game tidak ditemukan.' });

    const { name, image, status } = req.body || {};
    if (status && !['active', 'inactive'].includes(status)) {
      return res.status(400).json({ error: "status harus 'active' atau 'inactive'." });
    }

    const data = {};
    if (name !== undefined) data.name = name;
    if (image !== undefined) data.image = image;
    if (status !== undefined) data.status = status;

    const updated = await prisma.game.update({ where: { id: req.params.id }, data });
    await logAdminAction(req, 'update_game', `Update game "${existing.name}": ${JSON.stringify(data)}`);
    res.json(updated);
  })
);

// ============================================================
// 35 & 36. KELOLA PRODUK + KELOLA HARGA
// (satu endpoint yang sama menangani keduanya — harga cuma salah satu field produk)
// ============================================================
router.get(
  '/products',
  asyncHandler(async (req, res) => {
    const { gameId } = req.query;
    const products = await prisma.product.findMany({
      where: gameId ? { gameId } : undefined,
      include: { game: { select: { name: true, slug: true } } },
      orderBy: { createdAt: 'desc' },
      take: 300,
    });
    res.json(products);
  })
);

router.post(
  '/products',
  asyncHandler(async (req, res) => {
    const { gameId, name, description, providerPrice, sellingPrice } = req.body || {};
    if (!gameId || !name || sellingPrice === undefined) {
      return res.status(400).json({ error: 'gameId, name, dan sellingPrice wajib diisi.' });
    }
    const game = await prisma.game.findUnique({ where: { id: gameId } });
    if (!game) return res.status(404).json({ error: 'Game tidak ditemukan.' });

    // providerProductId SENGAJA tidak bisa diisi saat create — produk baru selalu mulai
    // dengan providerProductId = null (topup otomatis ditolak sampai dipetakan, lihat
    // utils/topup.js), lalu dipetakan lewat PATCH /products/:id/provider-mapping yang
    // memvalidasi ke katalog Digiflazz asli.
    const product = await prisma.product.create({
      data: {
        gameId,
        providerProductId: null,
        name,
        description: description || null,
        providerPrice: providerPrice ?? sellingPrice,
        sellingPrice,
      },
    });
    await logAdminAction(req, 'create_product', `Membuat produk "${name}" di game "${game.name}"`);
    res.status(201).json(product);
  })
);

// PATCH /api/admin/products/:id — update produk (nama, deskripsi, harga, status).
// providerProductId SENGAJA TIDAK BISA diubah lewat sini — lihat endpoint khusus
// /products/:id/provider-mapping di bawah, yang memvalidasi SKU ke katalog Digiflazz asli
// dulu sebelum disimpan (mencegah typo SKU yang baru ketahuan pas top up gagal).
router.patch(
  '/products/:id',
  asyncHandler(async (req, res) => {
    const existing = await prisma.product.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: 'Produk tidak ditemukan.' });

    const { name, description, providerPrice, sellingPrice, status } = req.body || {};
    if (status && !['active', 'inactive'].includes(status)) {
      return res.status(400).json({ error: "status harus 'active' atau 'inactive'." });
    }
    if (req.body && req.body.providerProductId !== undefined) {
      return res.status(400).json({
        error: 'providerProductId tidak bisa diubah lewat endpoint ini. Gunakan PATCH /products/:id/provider-mapping.',
      });
    }

    const data = {};
    if (name !== undefined) data.name = name;
    if (description !== undefined) data.description = description;
    if (providerPrice !== undefined) data.providerPrice = providerPrice;
    if (sellingPrice !== undefined) data.sellingPrice = sellingPrice;
    if (status !== undefined) data.status = status;

    const updated = await prisma.product.update({ where: { id: req.params.id }, data });

    const priceChanged = sellingPrice !== undefined && Number(sellingPrice) !== Number(existing.sellingPrice);
    await logAdminAction(
      req,
      priceChanged ? 'update_product_price' : 'update_product',
      priceChanged
        ? `Ubah harga "${existing.name}" dari Rp${Number(existing.sellingPrice).toLocaleString('id-ID')} ke Rp${Number(sellingPrice).toLocaleString('id-ID')}`
        : `Update produk "${existing.name}": ${JSON.stringify(data)}`
    );

    res.json(updated);
  })
);

// ============================================================
// PRIORITAS 3 — Hubungkan Digiflazz: mapping providerProductId -> SKU asli
//
//   Product ID (database)  →  providerProductId (kolom kita)  →  buyer_sku_code (Digiflazz)
//
// Dua endpoint di bawah ini yang menjembatani rantai itu.
// ============================================================

// GET /api/admin/digiflazz/price-list?search=&brand= — proxy KATALOG ASLI dari akun
// Digiflazz kamu. Dipakai admin buat CARI kode SKU yang benar sebelum dipasang ke produk —
// jadi tidak perlu buka dashboard Digiflazz terpisah, dan tidak asal ketik SKU dari ingatan.
router.get(
  '/digiflazz/price-list',
  asyncHandler(async (req, res) => {
    const { search, brand } = req.query;
    let list;
    try {
      list = await digiflazz.getPriceList();
    } catch (err) {
      return res.status(502).json({ error: `Gagal mengambil data dari Digiflazz: ${err.message}` });
    }

    let filtered = list;
    if (brand) filtered = filtered.filter((p) => (p.brand || '').toLowerCase() === brand.toLowerCase());
    if (search) {
      const q = search.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          (p.product_name || '').toLowerCase().includes(q) || (p.buyer_sku_code || '').toLowerCase().includes(q)
      );
    }
    res.json(filtered.slice(0, 200)); // batasi respons — katalog Digiflazz bisa ribuan baris
  })
);

// PATCH /api/admin/products/:id/provider-mapping — SATU-SATUNYA cara memasang/mengubah
// providerProductId. SKU yang dikirim DIVALIDASI dulu ke katalog Digiflazz asli (bukan
// cuma diterima mentah-mentah sebagai string) — kalau SKU tidak ditemukan atau sedang
// nonaktif di Digiflazz, request ditolak SEBELUM sempat tersimpan salah. Harga modal
// (providerPrice) juga otomatis disinkronkan dari data Digiflazz sekalian.
router.patch(
  '/products/:id/provider-mapping',
  asyncHandler(async (req, res) => {
    const { providerProductId } = req.body || {};
    if (!providerProductId || typeof providerProductId !== 'string') {
      return res.status(400).json({ error: 'providerProductId wajib diisi.' });
    }

    const product = await prisma.product.findUnique({ where: { id: req.params.id } });
    if (!product) return res.status(404).json({ error: 'Produk tidak ditemukan.' });

    let matched;
    try {
      const list = await digiflazz.getPriceList();
      matched = list.find((p) => p.buyer_sku_code === providerProductId);
    } catch (err) {
      return res.status(502).json({ error: `Gagal validasi ke Digiflazz: ${err.message}` });
    }
    if (!matched) {
      return res.status(400).json({
        error: `SKU "${providerProductId}" tidak ditemukan di katalog Digiflazz kamu. Cari dulu lewat GET /api/admin/digiflazz/price-list.`,
      });
    }
    if (matched.buyer_product_status === false || matched.seller_product_status === false) {
      return res.status(400).json({
        error: `SKU "${providerProductId}" (${matched.product_name}) sedang NONAKTIF di Digiflazz — jangan dipetakan dulu.`,
      });
    }

    const updated = await prisma.product.update({
      where: { id: product.id },
      data: {
        providerProductId,
        providerPrice: matched.price, // sinkronkan harga modal asli dari Digiflazz
      },
    });

    await logAdminAction(
      req,
      'map_provider_product',
      `Petakan produk "${product.name}" -> Digiflazz SKU "${providerProductId}" (${matched.product_name}, harga modal Rp${Number(matched.price).toLocaleString('id-ID')})`
    );

    res.json(updated);
  })
);
router.get(
  '/vouchers',
  asyncHandler(async (req, res) => {
    const vouchers = await prisma.voucher.findMany({ orderBy: { createdAt: 'desc' }, take: 200 });
    res.json(vouchers);
  })
);

router.post(
  '/vouchers',
  asyncHandler(async (req, res) => {
    const { code, type, value, minimumTransaction, maximumDiscount, usageLimit, expiredAt } = req.body || {};
    if (!code || !type || value === undefined) {
      return res.status(400).json({ error: 'code, type, dan value wajib diisi.' });
    }
    if (!['percentage', 'fixed'].includes(type)) {
      return res.status(400).json({ error: "type harus 'percentage' atau 'fixed'." });
    }

    const codeUpper = String(code).toUpperCase();
    const existing = await prisma.voucher.findUnique({ where: { code: codeUpper } });
    if (existing) return res.status(409).json({ error: 'Kode voucher sudah dipakai.' });

    const voucher = await prisma.voucher.create({
      data: {
        code: codeUpper,
        type,
        value,
        minimumTransaction: minimumTransaction || 0,
        maximumDiscount: maximumDiscount ?? null,
        usageLimit: usageLimit ?? null,
        expiredAt: expiredAt ? new Date(expiredAt) : null,
      },
    });
    await logAdminAction(req, 'create_voucher', `Membuat voucher "${voucher.code}"`);
    res.status(201).json(voucher);
  })
);

router.patch(
  '/vouchers/:id',
  asyncHandler(async (req, res) => {
    const existing = await prisma.voucher.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: 'Voucher tidak ditemukan.' });

    const { value, minimumTransaction, maximumDiscount, usageLimit, expiredAt, status } = req.body || {};
    if (status && !['active', 'inactive'].includes(status)) {
      return res.status(400).json({ error: "status harus 'active' atau 'inactive'." });
    }

    const data = {};
    if (value !== undefined) data.value = value;
    if (minimumTransaction !== undefined) data.minimumTransaction = minimumTransaction;
    if (maximumDiscount !== undefined) data.maximumDiscount = maximumDiscount;
    if (usageLimit !== undefined) data.usageLimit = usageLimit;
    if (expiredAt !== undefined) data.expiredAt = expiredAt ? new Date(expiredAt) : null;
    if (status !== undefined) data.status = status;

    const updated = await prisma.voucher.update({ where: { id: req.params.id }, data });
    await logAdminAction(req, 'update_voucher', `Update voucher "${existing.code}": ${JSON.stringify(data)}`);
    res.json(updated);
  })
);

// ============================================================
// 38. KELOLA ORDER  (+ dipakai juga buat 39/40 lewat query filter)
// ============================================================
router.get(
  '/orders',
  asyncHandler(async (req, res) => {
    const { paymentStatus, topupStatus, search } = req.query;
    const where = {};
    if (paymentStatus) where.paymentStatus = paymentStatus;
    if (topupStatus) where.topupStatus = topupStatus;
    if (search) {
      where.OR = [
        { orderNumber: { contains: search, mode: 'insensitive' } },
        { customerEmail: { contains: search, mode: 'insensitive' } },
      ];
    }
    const orders = await prisma.order.findMany({
      where,
      include: { game: { select: { name: true } }, product: { select: { name: true } } },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    res.json(orders);
  })
);

// Override manual buat kasus dukungan pelanggan (mis. tandai gagal/kedaluwarsa manual).
// PENTING: paymentStatus='paid' SENGAJA TIDAK BOLEH lewat endpoint generik ini — kalau admin
// perlu menandai lunas manual, itu harus lewat POST /orders/:id/mark-paid di bawah, supaya
// efek samping (poin, notifikasi, trigger topup) tetap konsisten jalan, bukan cuma ubah kolom.
router.patch(
  '/orders/:id',
  asyncHandler(async (req, res) => {
    const existing = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!existing) return res.status(404).json({ error: 'Order tidak ditemukan.' });

    const { paymentStatus, topupStatus, failureReason } = req.body || {};
    const validPayment = ['pending', 'failed', 'expired']; // 'paid' sengaja tidak termasuk
    const validTopup = ['pending', 'processing', 'success', 'failed'];
    if (paymentStatus && !validPayment.includes(paymentStatus)) {
      return res.status(400).json({
        error:
          paymentStatus === 'paid'
            ? "Tidak bisa set paymentStatus='paid' lewat endpoint ini. Gunakan POST /api/admin/orders/:id/mark-paid."
            : 'paymentStatus tidak valid.',
      });
    }
    if (topupStatus && !validTopup.includes(topupStatus)) {
      return res.status(400).json({ error: 'topupStatus tidak valid.' });
    }

    const data = {};
    if (paymentStatus !== undefined) data.paymentStatus = paymentStatus;
    if (topupStatus !== undefined) data.topupStatus = topupStatus;
    if (failureReason !== undefined) data.failureReason = failureReason;

    const updated = await prisma.order.update({ where: { id: req.params.id }, data });
    await logAdminAction(
      req,
      'override_order',
      `Override manual order ${existing.orderNumber}: ${JSON.stringify(data)}`
    );
    res.json(updated);
  })
);

// POST /api/admin/orders/:id/mark-paid — SATU-SATUNYA cara menandai order lunas secara
// manual (mis. verifikasi transfer manual di luar Tripay, atau webhook gagal masuk).
// Sengaja endpoint TERPISAH (bukan bagian dari PATCH generik di atas) dan WAJIB alasan,
// supaya aksi sesensitif ini tidak bisa "kesenggol" tanpa jejak yang jelas — ini yang
// dimaksud "mekanisme admin yang sangat terkontrol".
router.post(
  '/orders/:id/mark-paid',
  asyncHandler(async (req, res) => {
    const { reason } = req.body || {};
    if (!reason || typeof reason !== 'string' || reason.trim().length < 10) {
      return res
        .status(400)
        .json({ error: 'Wajib isi alasan (minimal 10 karakter) — ini tercatat permanen di admin_logs.' });
    }

    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: { payments: true },
    });
    if (!order) return res.status(404).json({ error: 'Order tidak ditemukan.' });
    if (order.paymentStatus !== 'pending') {
      return res
        .status(400)
        .json({ error: `Order ini sudah berstatus '${order.paymentStatus}', tidak bisa ditandai lunas manual.` });
    }

    // Pakai payment record pending yang sudah ada (dari POST /api/payments) kalau ada;
    // kalau tidak ada sama sekali (mis. customer transfer manual tanpa pernah buka Tripay),
    // buat catatan payment baru supaya tetap ada jejak di tabel payments.
    let payment = order.payments.find((p) => p.status === 'pending');
    if (!payment) {
      payment = await prisma.payment.create({
        data: {
          orderId: order.id,
          provider: 'manual_admin',
          paymentMethod: 'manual_admin',
          paymentReference: `ADMIN-${order.orderNumber}`,
          amount: order.amount,
          status: 'pending',
        },
      });
    }

    const result = await settleOrderPayment({
      payment,
      normalizedStatus: 'paid',
      rawResponse: { markedPaidByAdminId: req.user.id, reason: reason.trim() },
    });

    await logAdminAction(
      req,
      'manual_mark_paid',
      `Menandai order ${order.orderNumber} LUNAS secara manual. Alasan: ${reason.trim()}`
    );

    res.json(result.order);
  })
);

// ============================================================
// 39. MONITORING PAYMENT
// ============================================================
router.get(
  '/payments',
  asyncHandler(async (req, res) => {
    const { status } = req.query;
    const payments = await prisma.payment.findMany({
      where: status ? { status } : undefined,
      include: { order: { select: { orderNumber: true, customerEmail: true, amount: true } } },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    res.json(payments);
  })
);

// ============================================================
// 40. MONITORING TOP-UP
// Shortcut siap pakai di atas endpoint /orders — order yang sudah dibayar tapi
// topup-nya belum "success" (butuh perhatian admin).
// ============================================================
router.get(
  '/topups',
  asyncHandler(async (req, res) => {
    const { topupStatus } = req.query;
    const orders = await prisma.order.findMany({
      where: {
        paymentStatus: 'paid',
        topupStatus: topupStatus || { in: ['pending', 'processing', 'failed'] },
      },
      include: { game: { select: { name: true } }, product: { select: { name: true } } },
      orderBy: { updatedAt: 'desc' },
      take: 100,
    });
    res.json(orders);
  })
);

// ============================================================
// 41. USER MANAGEMENT
// ============================================================
router.get(
  '/users',
  asyncHandler(async (req, res) => {
    const users = await prisma.user.findMany({
      select: { id: true, name: true, email: true, role: true, rizpoint: true, createdAt: true },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    res.json(users);
  })
);

router.patch(
  '/users/:id/role',
  asyncHandler(async (req, res) => {
    const { role } = req.body || {};
    if (!['customer', 'admin'].includes(role)) {
      return res.status(400).json({ error: "role harus 'customer' atau 'admin'." });
    }
    if (req.params.id === req.user.id) {
      return res.status(400).json({ error: 'Tidak bisa mengubah role akun sendiri.' });
    }

    const target = await prisma.user.findUnique({ where: { id: req.params.id } });
    if (!target) return res.status(404).json({ error: 'User tidak ditemukan.' });

    const updated = await prisma.user.update({
      where: { id: req.params.id },
      data: { role },
      select: { id: true, name: true, email: true, role: true },
    });

    await logAdminAction(
      req,
      'update_user_role',
      `Mengubah role ${target.email} dari "${target.role}" ke "${role}"`
    );

    res.json(updated);
  })
);

// ============================================================
// 42. ADMIN LOGS
// ============================================================
router.get(
  '/logs',
  asyncHandler(async (req, res) => {
    const logs = await prisma.adminLog.findMany({
      include: { admin: { select: { name: true, email: true } } },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    res.json(logs);
  })
);

module.exports = router;
