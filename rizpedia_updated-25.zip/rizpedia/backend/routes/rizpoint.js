const express = require('express');
const prisma = require('../db');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { redeemPoints, RizpointError } = require('../utils/rizpoint');

const router = express.Router();

// GET /api/rizpoint — saldo RizPoint + riwayat transaksi poin milik user yang login
router.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });
    const transactions = await prisma.rizpointTransaction.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json({ balance: user.rizpoint, transactions });
  })
);

// POST /api/rizpoint/redeem — tukar RizPoint jadi diskon untuk order yang belum dibayar.
// Body: { orderId, points }
//
// Sama seperti voucher: seluruh proses (cek saldo + kunci pengurangan + catat riwayat +
// update nominal order) dibungkus SATU database transaction lewat redeemPoints(), supaya
// tidak ada celah dua request bersamaan sama-sama lolos dan bikin saldo poin jadi minus.
router.post(
  '/redeem',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { orderId, points } = req.body || {};
    if (!orderId || !points) {
      return res.status(400).json({ error: 'orderId dan points wajib diisi.' });
    }

    try {
      const updatedOrder = await prisma.$transaction(async (tx) => {
        const order = await tx.order.findUnique({ where: { id: orderId } });
        if (!order || order.userId !== req.user.id) {
          throw new RizpointError('Order tidak ditemukan.', 404);
        }
        if (order.paymentStatus !== 'pending') {
          throw new RizpointError('RizPoint hanya bisa dipakai sebelum order dibayar.', 400);
        }

        const { discount, pointsRedeemed } = await redeemPoints(tx, {
          userId: req.user.id,
          orderId: order.id,
          points,
        });

        if (discount > Number(order.amount)) {
          // Batalkan — lempar error supaya transaction di-rollback (poin yang sudah
          // "dipotong" di atas ikut dikembalikan otomatis oleh Prisma).
          throw new RizpointError(
            `Diskon dari ${pointsRedeemed} poin (Rp${discount.toLocaleString('id-ID')}) melebihi total order (Rp${Number(order.amount).toLocaleString('id-ID')}). Kurangi jumlah poin yang ditukar.`
          );
        }

        const newAmount = Math.max(0, Number(order.amount) - discount);
        const updated = await tx.order.update({ where: { id: order.id }, data: { amount: newAmount } });
        return { order: updated, discount, pointsRedeemed };
      });

      res.json(updatedOrder);
    } catch (err) {
      if (err instanceof RizpointError) {
        return res.status(err.status || 400).json({ error: err.message });
      }
      throw err;
    }
  })
);

module.exports = router;
