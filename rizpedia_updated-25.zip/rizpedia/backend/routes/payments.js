const express = require('express');
const crypto = require('crypto');
const prisma = require('../db');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const tripay = require('../utils/tripay');
const { expireIfOverdue } = require('../utils/orderExpiry');
const { settleOrderPayment } = require('../utils/settleOrderPayment');

const router = express.Router();
const PAYMENT_TIMEOUT_MINUTES = Number(process.env.PAYMENT_TIMEOUT_MINUTES || 5);

// POST /api/payments — mulai pembayaran untuk sebuah order.
// Body: { orderId, paymentMethod }  (paymentMethod = kode channel Tripay, mis. "QRIS", "BRIVA", "BCAVA")
//
// Kalau PAYMENT_PROVIDER=tripay dan kredensial di .env sudah diisi -> panggil API Tripay sungguhan.
// Kalau belum (PAYMENT_PROVIDER=manual, default) -> tetap jalan pakai referensi dummy,
// supaya development/testing UI bisa lanjut tanpa akun Tripay dulu.
router.post(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { orderId, paymentMethod } = req.body || {};
    if (!orderId || !paymentMethod) {
      return res.status(400).json({ error: 'orderId dan paymentMethod wajib diisi.' });
    }

    const order = await prisma.order.findUnique({ where: { id: orderId }, include: { product: true } });
    if (!order || order.userId !== req.user.id) {
      return res.status(404).json({ error: 'Order tidak ditemukan.' });
    }
    // Refresh status dulu — kalau ternyata batas waktu payment SEBELUMNYA sudah lewat
    // (lihat utils/orderExpiry.js), order ini akan otomatis ke-set 'expired' di sini,
    // jadi pengecekan di bawah akan menolaknya dengan benar (bukan bikin payment baru
    // di atas order yang sebenarnya sudah kedaluwarsa).
    await expireIfOverdue(orderId);
    const freshOrder = await prisma.order.findUnique({ where: { id: orderId } });
    if (freshOrder.paymentStatus !== 'pending') {
      return res.status(400).json({ error: 'Order ini sudah tidak menunggu pembayaran.' });
    }

    const provider = process.env.PAYMENT_PROVIDER || 'manual';
    let paymentReference;
    let expiredAt;
    let rawResponse = null;
    let instructions;

    if (provider === 'tripay') {
      const data = await tripay.createTransaction({
        method: paymentMethod,
        merchantRef: order.orderNumber,
        amount: Number(order.amount),
        customerName: order.customerName,
        customerEmail: order.customerEmail,
        orderItems: [
          {
            sku: order.productId,
            name: order.product.name,
            price: Number(order.amount),
            quantity: 1,
          },
        ],
      });
      paymentReference = data.reference;
      expiredAt = new Date(data.expired_time * 1000);
      rawResponse = data;
      // checkout_url / qr_url / pay_code dikirim balik ke frontend supaya bisa ditampilkan langsung
      instructions = {
        checkoutUrl: data.checkout_url,
        qrUrl: data.qr_url || null,
        payCode: data.pay_code || null,
        vaNumber: data.pay_code || null,
      };
    } else {
      // ===== Mode manual (default, tanpa akun Tripay) — untuk development/testing =====
      paymentReference = 'PAY-' + crypto.randomBytes(5).toString('hex').toUpperCase();
      expiredAt = new Date(Date.now() + PAYMENT_TIMEOUT_MINUTES * 60 * 1000);
      instructions = { note: `Mode manual: tandai lunas lewat webhook manual sebelum ${expiredAt.toLocaleString('id-ID')}.` };
    }

    const payment = await prisma.payment.create({
      data: {
        orderId: order.id,
        provider,
        paymentMethod,
        paymentReference,
        amount: order.amount,
        status: 'pending',
        expiredAt,
        rawResponse,
      },
    });

    await prisma.order.update({ where: { id: order.id }, data: { paymentReference } });

    res.status(201).json({ payment, instructions });
  })
);

// POST /api/payments/webhook — callback dari payment gateway.
// TIDAK pakai requireAuth (Tripay/provider luar yang panggil), TAPI signature WAJIB diverifikasi.
//
// Mode Tripay: verifikasi header X-Callback-Signature (HMAC-SHA256 raw body pakai Private Key).
// Mode manual (dev): verifikasi header x-webhook-secret sederhana, lihat PAYMENT_WEBHOOK_SECRET di .env.
router.post(
  '/webhook',
  asyncHandler(async (req, res) => {
    const provider = process.env.PAYMENT_PROVIDER || 'manual';
    let paymentReference;
    let normalizedStatus;

    if (provider === 'tripay') {
      const signature = req.headers['x-callback-signature'];
      const valid = tripay.verifyCallbackSignature(req.rawBody, signature);
      if (!valid) return res.status(401).json({ error: 'Signature Tripay tidak valid.' });

      const event = req.headers['x-callback-event'];
      if (event !== 'payment_status') {
        return res.status(200).json({ ok: true, ignored: event }); // event lain, abaikan tapi tetap 200
      }

      paymentReference = req.body.reference;
      normalizedStatus = tripay.mapTripayStatus(req.body.status);
    } else {
      const secret = req.headers['x-webhook-secret'];
      if (!process.env.PAYMENT_WEBHOOK_SECRET || secret !== process.env.PAYMENT_WEBHOOK_SECRET) {
        return res.status(401).json({ error: 'Webhook signature tidak valid.' });
      }
      paymentReference = req.body.paymentReference;
      normalizedStatus = ['paid', 'failed', 'expired'].includes(req.body.status) ? req.body.status : null;
    }

    if (!paymentReference || !normalizedStatus) {
      return res.status(400).json({ error: 'Payload webhook tidak lengkap/valid.' });
    }

    const payment = await prisma.payment.findFirst({ where: { paymentReference } });
    if (!payment) return res.status(404).json({ error: 'Payment tidak ditemukan.' });

    // Idempotensi + semua efek samping (poin, notifikasi, trigger topup) ditangani terpusat
    // di settleOrderPayment() — dipakai sama persis oleh mekanisme admin manual, lihat
    // routes/admin.js POST /orders/:id/mark-paid.
    const result = await settleOrderPayment({ payment, normalizedStatus, rawResponse: req.body });
    if (result.alreadyProcessed) {
      return res.json({ ok: true, alreadyProcessed: true });
    }

    res.json({ ok: true });
  })
);

module.exports = router;
