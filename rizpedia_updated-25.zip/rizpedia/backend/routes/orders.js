const express = require('express');
const prisma = require('../db');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { generateOrderNumber } = require('../utils/orderNumber');
const { claimVoucher, VoucherError } = require('../utils/voucher');
const { expireIfOverdue } = require('../utils/orderExpiry');

const router = express.Router();

// POST /api/orders — bikin order baru. Status awal: paymentStatus=pending, topupStatus=pending.
// Body: { productId, targetId, serverId?, voucherCode? }
//
// Kalau voucherCode disertakan, pembuatan order + klaim voucher dibungkus SATU database
// transaction (lihat claimVoucher() di utils/voucher.js) supaya tidak ada race condition
// kalau ada 2 request checkout bersamaan pakai voucher yang sama.
router.post(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { productId, targetId, serverId, voucherCode } = req.body || {};
    if (!productId || typeof productId !== 'string') {
      return res.status(400).json({ error: 'productId wajib diisi.' });
    }
    if (!targetId || typeof targetId !== 'string' || !targetId.trim()) {
      return res.status(400).json({ error: 'targetId (User ID/Zone ID) wajib diisi.' });
    }
    // Sanitasi ringan: trim + batas panjang, jangan simpan sampah/whitespace apa adanya
    // dari input client (target/server ID cuma dipakai buat dikirim ke provider nanti).
    const cleanTargetId = targetId.trim().slice(0, 100);
    const cleanServerId =
      serverId && typeof serverId === 'string' && serverId.trim() ? serverId.trim().slice(0, 100) : null;

    try {
      const result = await prisma.$transaction(async (tx) => {
        const product = await tx.product.findUnique({ where: { id: productId }, include: { game: true } });
        if (!product || product.status !== 'active' || product.game.status !== 'active') {
          throw new VoucherError('Produk tidak ditemukan atau sedang tidak aktif.', 404);
        }

        const user = await tx.user.findUnique({ where: { id: req.user.id } });
        let amount = Number(product.sellingPrice);
        let discount = 0;

        const order = await tx.order.create({
          data: {
            orderNumber: generateOrderNumber(),
            userId: user.id,
            gameId: product.gameId,
            productId: product.id,
            targetId: cleanTargetId,
            serverId: cleanServerId,
            customerName: user.name,
            customerEmail: user.email,
            amount, // diupdate di bawah kalau voucherCode valid
          },
        });

        if (voucherCode) {
          const claimResult = await claimVoucher(tx, { code: voucherCode, userId: user.id, orderId: order.id, amount });
          discount = claimResult.discount;
          amount = Math.max(0, amount - discount);
          await tx.order.update({ where: { id: order.id }, data: { amount } });
          order.amount = amount;
        }

        return { order, discount };
      });

      res.status(201).json(result);
    } catch (err) {
      if (err instanceof VoucherError) {
        return res.status(err.status || 400).json({ error: err.message });
      }
      throw err;
    }
  })
);

// GET /api/orders — daftar order milik user yang login (buat halaman "Cek Transaksi").
// Bukan buat siapa pun lihat order orang lain — makanya where selalu di-scope ke req.user.id.
router.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const orders = await prisma.order.findMany({
      where: { userId: req.user.id },
      include: {
        game: { select: { name: true } },
        product: { select: { name: true } },
        payments: { orderBy: { createdAt: 'desc' }, take: 1 },
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json(orders);
  })
);

// GET /api/orders/:id — detail order (hanya pemilik order atau admin)
router.get(
  '/:id',
  requireAuth,
  asyncHandler(async (req, res) => {
    // Lazy-check: kalau order ini masih "pending" tapi batas waktu bayarnya sudah lewat,
    // tandai kedaluwarsa dulu sebelum dikirim ke client (lihat utils/orderExpiry.js).
    await expireIfOverdue(req.params.id);

    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: { game: true, product: true, payments: true },
    });
    if (!order) return res.status(404).json({ error: 'Order tidak ditemukan.' });
    if (order.userId !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Kamu tidak punya akses ke order ini.' });
    }
    res.json(order);
  })
);

module.exports = router;
