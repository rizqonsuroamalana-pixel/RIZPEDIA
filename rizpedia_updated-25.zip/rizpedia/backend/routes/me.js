const express = require('express');
const prisma = require('../db');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');

const router = express.Router();

// GET /api/me — profil user yang sedang login
router.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await prisma.user.findUnique({ where: { id: req.user.id } });
    if (!user) return res.status(404).json({ error: 'User tidak ditemukan.' });
    const { passwordHash, ...safe } = user;
    res.json(safe);
  })
);

module.exports = router;
