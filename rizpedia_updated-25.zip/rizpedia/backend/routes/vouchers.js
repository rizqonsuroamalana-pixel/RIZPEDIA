const express = require('express');
const prisma = require('../db');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { checkVoucher, claimVoucher, VoucherError } = require('../utils/voucher');

const router = express.Router();

// POST /api/vouchers/validate — cek voucher TANPA memakainya (buat live-preview di UI keranjang).
// Ini CUMA preview, tidak mengunci kuota apa pun — validasi yang benar-benar mengikat
// selalu terjadi di /use (lihat komentar di utils/voucher.js).
// Body: { code, amount }
router.post(
  '/validate',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { code, amount } = req.body || {};
    if (!code || amount === undefined) {
      return res.status(400).json({ error: 'code dan amount wajib diisi.' });
    }
    const result = await checkVoucher(code, req.user.id, Number(amount));
    if (!result.ok) return res.status(400).json({ valid: false, error: result.reason });
    res.json({
      valid: true,
      discount: result.discount,
      finalAmount: Math.max(0, Number(amount) - result.discount),
    });
  })
);

// POST /api/vouchers/use — pakai voucher untuk order yang sudah dibuat tapi belum dibayar.
// Body: { code, orderId }
//
// Seluruh proses (cek ulang + kunci kuota + catat usage + update nominal order)
// dibungkus SATU database transaction lewat claimVoucher(), supaya tidak ada celah
// dua request bersamaan sama-sama lolos dan bikin kuota voucher kebobol.
router.post(
  '/use',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { code, orderId } = req.body || {};
    if (!code || !orderId) {
      return res.status(400).json({ error: 'code dan orderId wajib diisi.' });
    }

    try {
      const updatedOrder = await prisma.$transaction(async (tx) => {
        const order = await tx.order.findUnique({ where: { id: orderId } });
        if (!order || order.userId !== req.user.id) {
          throw new VoucherError('Order tidak ditemukan.', 404);
        }
        if (order.paymentStatus !== 'pending') {
          throw new VoucherError('Voucher hanya bisa dipakai sebelum order dibayar.', 400);
        }

        const { discount } = await claimVoucher(tx, {
          code,
          userId: req.user.id,
          orderId: order.id,
          amount: Number(order.amount),
        });

        const newAmount = Math.max(0, Number(order.amount) - discount);
        const updated = await tx.order.update({ where: { id: order.id }, data: { amount: newAmount } });
        return { order: updated, discount };
      });

      res.json(updatedOrder);
    } catch (err) {
      if (err instanceof VoucherError) {
        return res.status(err.status || 400).json({ error: err.message });
      }
      throw err;
    }
  })
);

module.exports = router;
