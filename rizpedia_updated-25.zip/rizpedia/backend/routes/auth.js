const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const prisma = require('../db');
const asyncHandler = require('../utils/asyncHandler');
const { isValidEmail, isNonEmptyString } = require('../utils/validate');

const router = express.Router();

// JWT_ALG dikunci eksplisit (bukan dibiarkan default library) supaya tidak rentan
// "algorithm confusion attack" — server HARUS menolak token yang mengklaim pakai
// algoritma lain (termasuk "none"). Lihat juga middleware/auth.js.
const JWT_ALG = 'HS256';

function signToken(user) {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
    algorithm: JWT_ALG,
  });
}

function toSafeUser(user) {
  const { passwordHash, ...safe } = user;
  return safe;
}

// POST /api/auth/register
router.post(
  '/register',
  asyncHandler(async (req, res) => {
    const { name, email, password } = req.body || {};
    if (!isNonEmptyString(name, 100)) {
      return res.status(400).json({ error: 'Nama wajib diisi (maksimal 100 karakter).' });
    }
    if (!isValidEmail(email)) {
      return res.status(400).json({ error: 'Format email tidak valid.' });
    }
    if (typeof password !== 'string' || password.length < 6 || password.length > 72) {
      // 72 = batas aman input bcrypt, bukan angka sembarang.
      return res.status(400).json({ error: 'Password minimal 6 karakter (maksimal 72).' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existing = await prisma.user.findUnique({ where: { email: normalizedEmail } });
    if (existing) {
      return res.status(409).json({ error: 'Email sudah terdaftar. Silakan login.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await prisma.user.create({
      data: { name: name.trim(), email: normalizedEmail, passwordHash },
    });

    const token = signToken(user);
    res.status(201).json({ token, user: toSafeUser(user) });
  })
);

// POST /api/auth/login
router.post(
  '/login',
  asyncHandler(async (req, res) => {
    const { email, password } = req.body || {};
    if (!isValidEmail(email) || typeof password !== 'string' || !password) {
      // Sengaja pesan generik (bukan "email tidak valid" vs "password kosong" terpisah)
      // supaya tidak membocorkan detail yang membantu enumerasi akun.
      return res.status(400).json({ error: 'Email dan password wajib diisi dengan format yang benar.' });
    }

    const user = await prisma.user.findUnique({ where: { email: email.trim().toLowerCase() } });
    if (!user) return res.status(401).json({ error: 'Email atau password salah.' });

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(401).json({ error: 'Email atau password salah.' });

    const token = signToken(user);
    res.json({ token, user: toSafeUser(user) });
  })
);

module.exports = router;
