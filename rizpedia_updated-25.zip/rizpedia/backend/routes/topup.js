const express = require('express');
const prisma = require('../db');
const { requireAuth } = require('../middleware/auth');
const asyncHandler = require('../utils/asyncHandler');
const { triggerTopup } = require('../utils/topup');

const router = express.Router();

// POST /api/topup — trigger/retry proses top up ke provider game untuk order yang sudah lunas.
// Body: { orderId }
// Biasanya dipanggil otomatis dari webhook pembayaran; endpoint ini untuk retry manual
// (oleh pemilik order atau admin) kalau top up sebelumnya gagal.
router.post(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { orderId } = req.body || {};
    if (!orderId) return res.status(400).json({ error: 'orderId wajib diisi.' });

    const order = await prisma.order.findUnique({ where: { id: orderId } });
    if (!order) return res.status(404).json({ error: 'Order tidak ditemukan.' });
    if (order.userId !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Kamu tidak punya akses ke order ini.' });
    }
    if (order.paymentStatus !== 'paid') {
      return res.status(400).json({ error: 'Order belum lunas, top up belum bisa diproses.' });
    }
    if (order.topupStatus === 'success') {
      return res.status(400).json({ error: 'Top up untuk order ini sudah berhasil sebelumnya.' });
    }

    const updated = await triggerTopup(order.id);
    res.json(updated);
  })
);

module.exports = router;
