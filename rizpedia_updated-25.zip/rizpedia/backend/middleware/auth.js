const jwt = require('jsonwebtoken');

// Wajib login: ambil token dari header "Authorization: Bearer <token>"
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) {
    return res.status(401).json({ error: 'Token tidak ditemukan. Silakan login terlebih dahulu.' });
  }
  try {
    // algorithms dikunci eksplisit ke HS256 — TANPA ini, library jwt akan menerima
    // token dengan algoritma apa pun yang tertulis di header token itu sendiri
    // (termasuk celah klasik "alg: none"). Harus sama dengan yang dipakai di routes/auth.js.
    const payload = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
    req.user = payload; // { id, email, role }
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Token tidak valid atau sudah kedaluwarsa.' });
  }
}

// Dipakai setelah requireAuth, untuk endpoint khusus admin
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Akses ini khusus admin.' });
  }
  next();
}

module.exports = { requireAuth, requireAdmin };
