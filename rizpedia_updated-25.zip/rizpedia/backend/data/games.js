// Data harga acuan pasar Codashop/UniPin/Lapakgaming Indonesia per game
// Estimasi Agustus 2026. Perbarui berkala sesuai harga publisher/reseller resmi.
//
// providerProductId (WAJIB diisi sebelum go-live):
// Tambahkan field `providerProductId` di tiap denom kalau produk itu sudah dipetakan
// ke SKU/kode produk ASLI dari provider H2H kamu (mis. Digiflazz, VIP Reseller).
// Contoh: { amt: 172, price: 40500, providerProductId: 'ML172' }
// Kalau field ini belum ditambahkan, seed akan menyimpan providerProductId = null,
// dan `utils/topup.js` akan MENOLAK memproses top up untuk produk itu (bukan
// dianggap "berhasil" secara diam-diam) sampai kamu isi ID asli dari provider.

module.exports = {
  MLBB: {
    unit: 'Diamond',
    denoms: [
      { amt: 86, price: 23000 },
      { amt: 172, price: 40500, old: 45000, badge: 'FLASH SALE' },
      { amt: 257, price: 67500 },
      { amt: 565, price: 150000 },
      { amt: 878, price: 218500 },
      { amt: 'Starlight', unit: 'Member', price: 149000, badge: 'SPECIAL', special: true },
    ],
  },
  FF: {
    unit: 'Diamond',
    denoms: [
      { amt: 25, price: 3500 },
      { amt: 100, price: 14000 },
      { amt: 210, price: 25500, old: 27600, badge: 'FLASH SALE' },
      { amt: 355, price: 46000 },
      { amt: 1000, price: 140000 },
      { amt: 'Membership', unit: 'Mingguan', price: 30000, badge: 'SPECIAL', special: true },
    ],
  },
  PUBG: {
    unit: 'UC',
    denoms: [
      { amt: 60, price: 15000 },
      { amt: 325, price: 69900, old: 74900, badge: 'FLASH SALE' },
      { amt: 660, price: 149800 },
      { amt: 1800, price: 374500 },
      { amt: 3850, price: 740000 },
      { amt: 'Royal Pass', unit: '', price: 149000, badge: 'SPECIAL', special: true },
    ],
  },
  GI: {
    unit: 'Genesis Crystal',
    denoms: [
      { amt: 60, price: 16000 },
      { amt: 300, price: 49000 },
      { amt: 980, price: 159000, old: 172000, badge: 'FLASH SALE' },
      { amt: 1980, price: 363000 },
      { amt: 3280, price: 589000 },
      { amt: 'Blessing', unit: 'Welkin Moon', price: 79000, badge: 'SPECIAL', special: true },
    ],
  },
  VAL: {
    unit: 'VP',
    denoms: [
      { amt: 475, price: 59000 },
      { amt: 1000, price: 109000, old: 119000, badge: 'FLASH SALE' },
      { amt: 2050, price: 229000 },
      { amt: 3650, price: 399000 },
      { amt: 5350, price: 569000 },
      { amt: 'Battle Pass', unit: 'Bundle', price: 149000, badge: 'SPECIAL', special: true },
    ],
  },
  RBX: {
    unit: 'Robux',
    denoms: [
      { amt: 80, price: 15000 },
      { amt: 400, price: 69000, old: 75000, badge: 'FLASH SALE' },
      { amt: 800, price: 150000 },
      { amt: 1700, price: 310000 },
      { amt: 4500, price: 780000 },
      { amt: 'Roblox', unit: 'Premium', price: 99000, badge: 'SPECIAL', special: true },
    ],
  },
  GPL: {
    unit: '',
    denoms: [
      { amt: 'Rp 12.000', unit: '', price: 12500 },
      { amt: 'Rp 60.000', unit: '', price: 57000, old: 60000, badge: 'FLASH SALE' },
      { amt: 'Rp 100.000', unit: '', price: 96500 },
      { amt: 'Rp 300.000', unit: '', price: 289000 },
      { amt: 'Rp 500.000', unit: '', price: 481000 },
      { amt: 'Rp 1.000.000', unit: '', price: 962000 },
    ],
  },
  STM: {
    unit: '',
    denoms: [
      { amt: 'Rp 45.000', unit: '', price: 44000 },
      { amt: 'Rp 90.000', unit: '', price: 85000, old: 89000, badge: 'FLASH SALE' },
      { amt: 'Rp 250.000', unit: '', price: 238000 },
      { amt: 'Rp 500.000', unit: '', price: 476000 },
      { amt: 'Rp 1.000.000', unit: '', price: 952000 },
      { amt: 'Rp 2.000.000', unit: '', price: 1904000 },
    ],
  },
  TSL: {
    unit: '',
    denoms: [
      { amt: 'Pulsa Rp5.000', unit: '', price: 6500 },
      { amt: 'Pulsa Rp10.000', unit: '', price: 11500, old: 12500, badge: 'FLASH SALE' },
      { amt: 'Pulsa Rp25.000', unit: '', price: 26500 },
      { amt: 'Pulsa Rp50.000', unit: '', price: 50500 },
      { amt: 'Data 3GB/30hr', unit: '', price: 35000 },
      { amt: 'Data 10GB/30hr', unit: '', price: 75000, badge: 'SPECIAL', special: true },
    ],
  },
  PLN: {
    unit: '',
    denoms: [
      { amt: 'Token Rp20.000', unit: '', price: 22500 },
      { amt: 'Token Rp50.000', unit: '', price: 52000, old: 55000, badge: 'FLASH SALE' },
      { amt: 'Token Rp100.000', unit: '', price: 102500 },
      { amt: 'Token Rp200.000', unit: '', price: 202500 },
      { amt: 'Token Rp500.000', unit: '', price: 502500 },
      { amt: 'Token Rp1.000.000', unit: '', price: 1002500 },
    ],
  },
  XL: {
    unit: '',
    denoms: [
      { amt: 'Pulsa Rp5.000', unit: '', price: 6500 },
      { amt: 'Pulsa Rp10.000', unit: '', price: 11000, old: 12000, badge: 'FLASH SALE' },
      { amt: 'Pulsa Rp25.000', unit: '', price: 25500 },
      { amt: 'Data 2GB/30hr', unit: '', price: 25000 },
      { amt: 'Data 8GB/30hr', unit: '', price: 55000 },
      { amt: 'Data 25GB/30hr', unit: '', price: 99000, badge: 'SPECIAL', special: true },
    ],
  },
  SPT: {
    unit: '',
    denoms: [
      { amt: 'Individual', unit: '1 Bulan', price: 54990 },
      { amt: 'Individual', unit: '3 Bulan', price: 149000, old: 164970, badge: 'FLASH SALE' },
      { amt: 'Duo', unit: '1 Bulan', price: 71990 },
      { amt: 'Family', unit: '1 Bulan', price: 86900 },
      { amt: 'Student', unit: '1 Bulan', price: 27500 },
      { amt: 'Individual', unit: '12 Bulan', price: 599000, badge: 'SPECIAL', special: true },
    ],
  },
};
