const crypto = require('crypto');
const prisma = require('../db');
const digiflazz = require('./digiflazz');

// Proses top up ke provider game setelah pembayaran sukses.
//
// H2H_PROVIDER=manual (default)   -> mode dev/testing: generate reference dummy, langsung "success".
// H2H_PROVIDER=digiflazz          -> panggil API Digiflazz sungguhan (lihat utils/digiflazz.js).
//
// Item "kirim transaksi", "provider reference", dan "cek status" semua lewat SATU jalur
// yang sama: submitTransaction() Digiflazz itu IDEMPOTEN berdasarkan ref_id (kita pakai
// order.orderNumber sebagai ref_id) — jadi memanggil triggerTopup() lagi untuk order yang
// sama otomatis berfungsi sebagai "cek status" / "retry", bukan mengirim transaksi baru
// ke provider.
async function triggerTopup(orderId) {
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { product: true } });
  if (!order) return null;
  if (order.paymentStatus !== 'paid') return order; // jangan proses kalau belum lunas

  // Idempotency lapis kedua: kalau order ini SUDAH pernah berhasil top up, jangan proses
  // ulang — walau fungsi ini terpanggil dobel dari jalur mana pun (webhook duplikat yang lolos,
  // retry manual admin, dsb), jangan sampai game providernya dikirim request top up 2x.
  if (order.topupStatus === 'success') return order;

  await prisma.order.update({ where: { id: orderId }, data: { topupStatus: 'processing' } });

  // Jangan pernah lanjut kalau produk ini belum dipetakan ke ID asli provider —
  // daripada diam-diam "sukses" padahal tidak ada apa pun yang benar-benar dikirim ke provider.
  if (!order.product.providerProductId) {
    const failed = await prisma.order.update({
      where: { id: orderId },
      data: {
        topupStatus: 'failed',
        failureReason: `Produk "${order.product.name}" belum punya providerProductId (belum dipetakan ke provider H2H). Isi dulu di backend/data/games.js lalu jalankan ulang npm run seed.`,
      },
    });
    if (order.userId) {
      await prisma.notification.create({
        data: {
          userId: order.userId,
          orderId: order.id,
          title: 'Top up tertunda',
          message: `Top up ${order.product.name} belum bisa diproses otomatis. Tim kami akan memprosesnya secara manual.`,
          type: 'warning',
        },
      });
    }
    return failed;
  }

  const providerName = process.env.H2H_PROVIDER || 'manual';

  try {
    let mappedStatus; // 'success' | 'failed' | 'processing'
    let providerReference;
    let failureReason = null;

    if (providerName === 'digiflazz') {
      // customerNo: sebagian besar game cuma butuh targetId, sebagian (mis. MLBB) butuh
      // targetId+serverId digabung. Sesuaikan format ini dengan requirement tiap game di
      // dashboard Digiflazz kamu kalau ternyata beda per produk.
      const customerNo = order.serverId ? `${order.targetId}${order.serverId}` : order.targetId;

      const data = await digiflazz.submitTransaction({
        buyerSkuCode: order.product.providerProductId,
        customerNo,
        refId: order.orderNumber, // idempotent: retry/cek status pakai refId yang sama
      });

      mappedStatus = digiflazz.mapDigiflazzStatus(data.status);
      providerReference = data.sn || data.ref_id;
      if (mappedStatus === 'failed') failureReason = data.message || 'Transaksi ditolak provider.';
    } else {
      // ===== Mode manual (default, tanpa akun Digiflazz) — untuk development/testing =====
      mappedStatus = 'success';
      providerReference = 'PROV-' + crypto.randomBytes(4).toString('hex').toUpperCase();
    }

    const updated = await prisma.order.update({
      where: { id: orderId },
      data: {
        topupStatus: mappedStatus, // bisa 'processing' kalau Digiflazz masih Pending
        providerReference,
        failureReason,
      },
    });

    if (order.userId) {
      if (mappedStatus === 'success') {
        await prisma.notification.create({
          data: {
            userId: order.userId,
            orderId: order.id,
            title: 'Top up berhasil',
            message: `Top up ${order.product.name} sudah diproses ke akun game kamu.`,
            type: 'success',
          },
        });
      } else if (mappedStatus === 'failed') {
        await prisma.notification.create({
          data: {
            userId: order.userId,
            orderId: order.id,
            title: 'Top up gagal',
            message: `Top up ${order.product.name} gagal diproses: ${failureReason || 'Ditolak provider.'}`,
            type: 'error',
          },
        });
      }
      // mappedStatus === 'processing' -> provider masih memproses, sengaja tidak kirim notifikasi
      // dulu supaya user tidak spam notif tiap kali di-retry/cek status; tunggu sampai final.
    }
    return updated;
  } catch (err) {
    const updated = await prisma.order.update({
      where: { id: orderId },
      data: { topupStatus: 'failed', failureReason: err.message },
    });
    if (order.userId) {
      await prisma.notification.create({
        data: {
          userId: order.userId,
          orderId: order.id,
          title: 'Top up gagal',
          message: `Top up ${order.product.name} gagal diproses. Tim kami akan menindaklanjuti.`,
          type: 'error',
        },
      });
    }
    return updated;
  }
}

module.exports = { triggerTopup };
