const crypto = require('crypto');

// Format: RZ-YYYYMMDD-XXXXXX (6 karakter hex acak)
function generateOrderNumber() {
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const rand = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `RZ-${stamp}-${rand}`;
}

module.exports = { generateOrderNumber };
