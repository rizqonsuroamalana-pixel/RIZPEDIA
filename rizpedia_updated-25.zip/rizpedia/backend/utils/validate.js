// Validasi ringan yang dipakai berulang di banyak route. Bukan library validasi skema
// penuh (zod/joi) — cukup buat menutup celah paling umum: format email, string kosong,
// dan angka yang seharusnya positif. Kalau nanti butuh validasi lebih kompleks per
// endpoint, pertimbangkan migrasi ke zod supaya skemanya lebih terstruktur.

function isValidEmail(email) {
  if (typeof email !== 'string') return false;
  // Regex simpel yang cukup ketat untuk validasi format umum (bukan RFC 5322 lengkap).
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function isNonEmptyString(value, maxLength = 255) {
  return typeof value === 'string' && value.trim().length > 0 && value.trim().length <= maxLength;
}

function isPositiveNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0;
}

module.exports = { isValidEmail, isNonEmptyString, isPositiveNumber };
