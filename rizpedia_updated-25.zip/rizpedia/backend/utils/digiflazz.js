const crypto = require('crypto');

// Dokumentasi resmi: https://developer.digiflazz.com
// Digiflazz tidak punya base URL sandbox terpisah — mode testing dilakukan dengan
// memakai produk ber-SKU testing (biasanya awalan tertentu dari Digiflazz) dan/atau
// akun yang masih berstatus "belum saldo" sehingga transaksi otomatis ditolak dengan
// aman. Cek dashboard Digiflazz kamu untuk daftar SKU testing yang tersedia.
const BASE_URL = 'https://api.digiflazz.com/v1';

function assertConfigured() {
  const required = ['DIGIFLAZZ_USERNAME', 'DIGIFLAZZ_API_KEY'];
  const missing = required.filter((k) => !process.env[k]);
  if (missing.length) {
    throw new Error(`Konfigurasi Digiflazz belum lengkap di .env: ${missing.join(', ')}`);
  }
}

// Signature transaksi Digiflazz = MD5(username + api_key + ref_id)
function signTransaction(refId) {
  return crypto
    .createHash('md5')
    .update(`${process.env.DIGIFLAZZ_USERNAME}${process.env.DIGIFLAZZ_API_KEY}${refId}`)
    .digest('hex');
}

// Kirim transaksi top up. PENTING: endpoint ini IDEMPOTEN berdasarkan `refId` —
// mengirim ulang request dengan refId yang SAMA tidak akan diproses dua kali oleh
// Digiflazz, cuma mengembalikan status transaksi yang sudah ada. Sifat ini yang kita
// manfaatkan buat 2 kebutuhan sekaligus:
//   - "Kirim transaksi" pertama kali  -> refId baru (pakai order.orderNumber)
//   - "Cek status" / "Retry"          -> refId SAMA (order.orderNumber yang sama lagi)
async function submitTransaction({ buyerSkuCode, customerNo, refId }) {
  assertConfigured();
  const sign = signTransaction(refId);

  const res = await fetch(`${BASE_URL}/transaction`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: process.env.DIGIFLAZZ_USERNAME,
      buyer_sku_code: buyerSkuCode,
      customer_no: customerNo,
      ref_id: refId,
      sign,
    }),
  });

  const json = await res.json();
  if (!json || !json.data) {
    throw new Error((json && json.message) || 'Respons Digiflazz tidak valid.');
  }
  // data: { ref_id, customer_no, buyer_sku_code, message, status: 'Pending'|'Sukses'|'Gagal', rc, sn, price, ... }
  return json.data;
}

// "Cek status" = panggil ulang endpoint yang sama dengan refId yang sama (lihat
// catatan idempotency di atas). Dipisah jadi fungsi sendiri supaya niatnya jelas
// di pemanggil (utils/topup.js), walau secara teknis sama persis dengan submitTransaction.
async function checkStatus({ buyerSkuCode, customerNo, refId }) {
  return submitTransaction({ buyerSkuCode, customerNo, refId });
}

// Status Digiflazz -> enum TopupStatus kita ('pending' | 'processing' | 'success' | 'failed')
function mapDigiflazzStatus(status) {
  const map = { Sukses: 'success', Gagal: 'failed', Pending: 'processing' };
  return map[status] || 'processing';
}

// Signature price-list Digiflazz = MD5(username + api_key + "pricelist")
function signPriceList() {
  return crypto
    .createHash('md5')
    .update(`${process.env.DIGIFLAZZ_USERNAME}${process.env.DIGIFLAZZ_API_KEY}pricelist`)
    .digest('hex');
}

// Ambil KATALOG ASLI Digiflazz (semua SKU yang tersedia untuk akun ini) — dipakai admin
// buat mencari kode SKU yang benar sebelum dipetakan ke providerProductId (lihat
// routes/admin.js: GET /digiflazz/price-list dan PATCH /products/:id/provider-mapping).
// Ini titik penghubung rantai "Product ID database -> providerProductId -> SKU Digiflazz".
async function getPriceList() {
  assertConfigured();
  const sign = signPriceList();

  const res = await fetch(`${BASE_URL}/price-list`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ cmd: 'prepaid', username: process.env.DIGIFLAZZ_USERNAME, sign }),
  });

  const json = await res.json();
  if (!json || !Array.isArray(json.data)) {
    throw new Error((json && json.message) || 'Gagal mengambil price list dari Digiflazz.');
  }
  // tiap item: { product_name, category, brand, type, seller_name, price, buyer_sku_code,
  //              buyer_product_status, seller_product_status, unlimited_stock, stock, desc, ... }
  return json.data;
}

module.exports = { submitTransaction, checkStatus, mapDigiflazzStatus, getPriceList };
