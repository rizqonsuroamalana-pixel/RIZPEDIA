const prisma = require('../db');
const { triggerTopup } = require('./topup');

// Menyelesaikan status SEBUAH payment + order terkait, dan menjalankan SEMUA efek
// samping yang seharusnya (award RizPoint, notifikasi, trigger topup ke provider).
//
// INI SATU-SATUNYA TEMPAT status order boleh berubah jadi 'paid' di seluruh backend —
// dipakai bareng oleh:
//   1. webhook Tripay yang sudah diverifikasi signature-nya (routes/payments.js)
//   2. mekanisme admin manual yang sangat terkontrol (routes/admin.js, POST .../mark-paid)
//
// Menyatukan logikanya di sini penting supaya KEDUA jalur itu punya PERILAKU YANG SAMA
// PERSIS — tidak ada order yang "paid" tapi lupa dikasih poin atau lupa di-topup cuma
// karena diproses lewat jalur yang beda.
async function settleOrderPayment({ payment, normalizedStatus, rawResponse = null }) {
  // Idempotensi: kalau statusnya sama seperti sebelumnya, jangan diproses ulang
  // (mencegah RizPoint dobel / topup dobel kalau dipanggil lebih dari sekali).
  if (payment.status === normalizedStatus) {
    return { alreadyProcessed: true, order: null };
  }

  await prisma.payment.update({
    where: { id: payment.id },
    data: {
      status: normalizedStatus,
      paidAt: normalizedStatus === 'paid' ? new Date() : null,
      rawResponse,
    },
  });

  const order = await prisma.order.update({
    where: { id: payment.orderId },
    data: {
      paymentStatus: normalizedStatus,
      failureReason: normalizedStatus !== 'paid' ? `Pembayaran ${normalizedStatus}` : null,
    },
  });

  if (normalizedStatus === 'paid') {
    const earnedPoints = Math.floor(Number(order.amount) / 1000);
    const ops = [];
    if (order.userId) {
      ops.push(
        prisma.rizpointTransaction.create({
          data: {
            userId: order.userId,
            orderId: order.id,
            type: 'earn',
            amount: earnedPoints,
            description: `Top up ${order.orderNumber}`,
          },
        }),
        prisma.user.update({ where: { id: order.userId }, data: { rizpoint: { increment: earnedPoints } } }),
        prisma.notification.create({
          data: {
            userId: order.userId,
            orderId: order.id,
            title: 'Pembayaran berhasil',
            message: `Pembayaran order ${order.orderNumber} berhasil dikonfirmasi.`,
            type: 'success',
          },
        })
      );
    }
    if (ops.length) await prisma.$transaction(ops);
    await triggerTopup(order.id);
  } else if (order.userId) {
    await prisma.notification.create({
      data: {
        userId: order.userId,
        orderId: order.id,
        title: 'Pembayaran gagal',
        message: `Pembayaran order ${order.orderNumber} berstatus ${normalizedStatus}.`,
        type: 'error',
      },
    });
  }

  return { alreadyProcessed: false, order };
}

module.exports = { settleOrderPayment };
