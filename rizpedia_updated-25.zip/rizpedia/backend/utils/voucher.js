const { Prisma } = require('@prisma/client');
const prisma = require('../db');

// ============================================================================
// checkVoucher — PREVIEW SAJA, tidak mengunci apa pun.
// Dipakai oleh POST /api/vouchers/validate supaya user dapat feedback cepat di UI
// SEBELUM checkout. Karena tidak mengunci, hasilnya bisa saja berubah (mis. kuota
// habis diambil orang lain) sebelum checkout beneran dieksekusi — makanya validasi
// akhir yang MENGIKAT selalu lewat claimVoucher() di bawah, di dalam transaction.
// ============================================================================
async function checkVoucher(code, userId, amount) {
  const voucher = await prisma.voucher.findUnique({ where: { code: String(code).toUpperCase() } });
  if (!voucher) return { ok: false, reason: 'Kode voucher tidak ditemukan.' };
  if (voucher.status !== 'active') return { ok: false, reason: 'Voucher tidak aktif.' };
  if (voucher.expiredAt && new Date() > voucher.expiredAt) {
    return { ok: false, reason: 'Voucher sudah kedaluwarsa.' };
  }
  if (voucher.usageLimit !== null && voucher.usedCount >= voucher.usageLimit) {
    return { ok: false, reason: 'Kuota pemakaian voucher ini sudah habis.' };
  }
  if (Number(amount) < Number(voucher.minimumTransaction)) {
    return {
      ok: false,
      reason: `Transaksi minimal Rp${Number(voucher.minimumTransaction).toLocaleString('id-ID')} untuk pakai voucher ini.`,
    };
  }
  const alreadyUsed = await prisma.voucherUsage.findFirst({ where: { voucherId: voucher.id, userId } });
  if (alreadyUsed) return { ok: false, reason: 'Voucher ini sudah pernah kamu pakai.' };

  return { ok: true, voucher, discount: computeDiscount(voucher, amount) };
}

function computeDiscount(voucher, amount) {
  let discount =
    voucher.type === 'percentage' ? (Number(amount) * Number(voucher.value)) / 100 : Number(voucher.value);
  if (voucher.maximumDiscount !== null) discount = Math.min(discount, Number(voucher.maximumDiscount));
  discount = Math.min(discount, Number(amount));
  return Math.floor(discount);
}

// ============================================================================
// claimVoucher — VALIDASI + KUNCI PENGGUNAAN, dijalankan di dalam satu
// database transaction (tx = Prisma transaction client yang di-pass masuk).
//
// Supaya tidak ada race condition (dua request checkout bersamaan pakai voucher
// yang sama, sama-sama lolos pengecekan, dan kuota kebobol lebih dari usage_limit),
// pengecekan kuota + increment used_count dijadikan SATU statement UPDATE atomik
// di database (bukan "SELECT lalu UPDATE terpisah" seperti sebelumnya):
//
//   UPDATE vouchers SET used_count = used_count + 1
//   WHERE id = ? AND status='active' AND (belum expired) AND (belum melebihi limit)
//
// Postgres mengunci baris itu untuk durasi transaction, jadi request kedua yang
// datang bersamaan akan menunggu, lalu gagal mencocokkan kondisi WHERE begitu
// gilirannya, dan langsung tahu kuota sudah habis — bukan sama-sama lolos.
//
// Lapis kedua: constraint unique(voucherId, userId) di tabel voucher_usage
// (lihat schema.prisma) mencegah user yang sama pakai voucher yang sama dua kali
// walau requestnya dikirim bersamaan.
// ============================================================================
async function claimVoucher(tx, { code, userId, orderId, amount }) {
  const normalizedCode = String(code).toUpperCase();

  // Cek awal yang murah (bukan penentu akhir) — supaya pesan error jelas sebelum coba klaim.
  const voucher = await tx.voucher.findUnique({ where: { code: normalizedCode } });
  if (!voucher) throw new VoucherError('Kode voucher tidak ditemukan.');
  if (voucher.status !== 'active') throw new VoucherError('Voucher tidak aktif.');
  if (voucher.expiredAt && new Date() > voucher.expiredAt) {
    throw new VoucherError('Voucher sudah kedaluwarsa.');
  }
  if (Number(amount) < Number(voucher.minimumTransaction)) {
    throw new VoucherError(
      `Transaksi minimal Rp${Number(voucher.minimumTransaction).toLocaleString('id-ID')} untuk pakai voucher ini.`
    );
  }

  // ===== Klaim atomik: increment used_count HANYA KALAU masih di bawah limit =====
  const claimed = await tx.$executeRaw`
    UPDATE vouchers
    SET used_count = used_count + 1, updated_at = now()
    WHERE id = ${voucher.id}
      AND status = 'active'
      AND (expired_at IS NULL OR expired_at > now())
      AND (usage_limit IS NULL OR used_count < usage_limit)
  `;
  if (claimed === 0) {
    // Kalah race / kuota baru saja habis di request lain yang lebih cepat.
    throw new VoucherError('Kuota voucher ini baru saja habis, coba voucher lain.');
  }

  const discount = computeDiscount(voucher, amount);

  try {
    await tx.voucherUsage.create({
      data: { voucherId: voucher.id, userId, orderId, discount },
    });
  } catch (err) {
    // Kena constraint unique(voucherId, userId) — user ini sudah pernah pakai voucher ini,
    // termasuk kalau request-nya dikirim dobel/bersamaan. Transaction akan di-rollback
    // otomatis oleh Prisma (termasuk increment used_count di atas), jadi kuota tidak bocor.
    if (err instanceof Prisma.PrismaClientKnownRequestError && err.code === 'P2002') {
      throw new VoucherError('Voucher ini sudah pernah kamu pakai.');
    }
    throw err;
  }

  return { voucher, discount };
}

class VoucherError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

module.exports = { checkVoucher, claimVoucher, VoucherError };
