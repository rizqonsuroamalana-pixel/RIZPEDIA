const crypto = require('crypto');

// Dokumentasi resmi: https://tripay.co.id/developer
const BASE_URL =
  process.env.TRIPAY_MODE === 'production' ? 'https://tripay.co.id/api' : 'https://tripay.co.id/api-sandbox';

function assertConfigured() {
  const required = ['TRIPAY_API_KEY', 'TRIPAY_PRIVATE_KEY', 'TRIPAY_MERCHANT_CODE'];
  const missing = required.filter((k) => !process.env[k]);
  if (missing.length) {
    throw new Error(`Konfigurasi Tripay belum lengkap di .env: ${missing.join(', ')}`);
  }
}

// Signature request transaksi baru = HMAC-SHA256(merchant_code + merchant_ref + amount) pakai Private Key
function createTransactionSignature(merchantRef, amount) {
  return crypto
    .createHmac('sha256', process.env.TRIPAY_PRIVATE_KEY)
    .update(process.env.TRIPAY_MERCHANT_CODE + merchantRef + amount)
    .digest('hex');
}

// method = kode channel pembayaran Tripay, mis. "QRIS", "BRIVA", "BCAVA", dst.
// (daftar lengkap: GET {BASE_URL}/merchant/payment-channel)
async function createTransaction({ method, merchantRef, amount, customerName, customerEmail, orderItems }) {
  assertConfigured();
  const signature = createTransactionSignature(merchantRef, amount);

  const body = {
    method,
    merchant_ref: merchantRef,
    amount,
    customer_name: customerName,
    customer_email: customerEmail,
    order_items: orderItems,
    callback_url: `${process.env.APP_BASE_URL}/api/payments/webhook`,
    return_url: `${process.env.APP_BASE_URL}/desktop.html`,
    expired_time: Math.floor(Date.now() / 1000) + Number(process.env.PAYMENT_TIMEOUT_MINUTES || 5) * 60,
    signature,
  };

  const res = await fetch(`${BASE_URL}/transaction/create`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.TRIPAY_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const json = await res.json();
  if (!res.ok || json.success === false) {
    throw new Error(json.message || 'Gagal membuat transaksi di Tripay.');
  }
  return json.data; // berisi reference, checkout_url, qr_url, pay_code, amount, expired_time, dll.
}

// Verifikasi header X-Callback-Signature dari webhook Tripay.
// WAJIB pakai raw body (belum di-parse JSON) supaya hash-nya cocok.
function verifyCallbackSignature(rawBody, signatureHeader) {
  if (!signatureHeader) return false;
  const expected = crypto.createHmac('sha256', process.env.TRIPAY_PRIVATE_KEY).update(rawBody).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signatureHeader));
}

// Status Tripay (PAID/EXPIRED/FAILED/REFUND/UNPAID) -> enum PaymentStatus kita
function mapTripayStatus(status) {
  const map = { PAID: 'paid', EXPIRED: 'expired', FAILED: 'failed', REFUND: 'failed', UNPAID: 'pending' };
  return map[status] || null;
}

module.exports = { createTransaction, verifyCallbackSignature, mapTripayStatus };
