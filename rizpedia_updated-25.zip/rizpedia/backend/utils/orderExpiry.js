const prisma = require('../db');

// Cek & tandai order KEDALUWARSA kalau payment pending-nya sudah lewat `expiredAt`
// dan belum ada kabar apa pun dari provider (mis. user kabur sebelum bayar, atau
// webhook "expired" dari provider belum/tidak pernah sampai).
//
// Dipanggil secara "lazy" — tiap kali order dibaca (GET /api/orders/:id) atau mau
// dipakai lagi (POST /api/payments) — bukan lewat cron job terpisah. Ini cukup buat
// skala aplikasi ini karena yang butuh tahu status terkini cuma user yang lagi
// lihat/poll order itu sendiri. Kalau nanti butuh auto-expire massal tanpa harus
// ada yang membuka order-nya dulu, tambahkan scheduled job yang query
// `payments` WHERE status='pending' AND expiredAt < now() lalu panggil fungsi ini.
async function expireIfOverdue(orderId) {
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { payments: { orderBy: { createdAt: 'desc' }, take: 1 } },
  });
  if (!order) return null;
  if (order.paymentStatus !== 'pending') return order; // sudah final (paid/failed/expired)

  const latestPayment = order.payments[0];
  if (!latestPayment || latestPayment.status !== 'pending' || !latestPayment.expiredAt) return order;
  if (new Date() <= latestPayment.expiredAt) return order; // belum lewat batas waktu

  await prisma.$transaction([
    prisma.payment.update({ where: { id: latestPayment.id }, data: { status: 'expired' } }),
    prisma.order.update({
      where: { id: orderId },
      data: { paymentStatus: 'expired', failureReason: 'Waktu pembayaran habis.' },
    }),
  ]);

  return prisma.order.findUnique({ where: { id: orderId } });
}

module.exports = { expireIfOverdue };
