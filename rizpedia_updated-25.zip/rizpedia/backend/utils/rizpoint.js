// Kebijakan konversi RizPoint -> diskon rupiah. 1 RizPoint didapat dari tiap Rp1.000
// belanja (lihat routes/payments.js), jadi biar simetris: 1 RizPoint = Rp1 diskon.
// Ini murni keputusan bisnis, gampang diubah — cukup ganti angka ini.
const POINT_VALUE_RUPIAH = 1;

class RizpointError extends Error {
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
}

// redeemPoints — VALIDASI + KUNCI PENGGUNAAN, dijalankan di dalam satu database
// transaction (tx = Prisma transaction client yang di-pass masuk), MENIRU POLA
// claimVoucher() di utils/voucher.js supaya konsisten:
//
// Race condition yang dicegah: user pakai 2 tab/device, kirim redeem barengan buat
// order yang sama atau order berbeda dengan total poin melebihi saldo. Makanya
// pengurangan saldo dibuat SATU UPDATE atomik bersyarat (bukan "SELECT saldo dulu,
// baru UPDATE terpisah"):
//
//   UPDATE users SET rizpoint = rizpoint - ? WHERE id = ? AND rizpoint >= ?
//
// Kalau affected rows = 0, berarti saldo tidak cukup (termasuk kalau kalah race
// sama request lain yang lebih dulu menghabiskan saldo) — request ini gagal bersih,
// tidak mungkin saldo jadi minus.
async function redeemPoints(tx, { userId, orderId, points }) {
  const pointsToRedeem = Math.floor(Number(points));
  if (!Number.isFinite(pointsToRedeem) || pointsToRedeem <= 0) {
    throw new RizpointError('Jumlah poin yang ditukar harus lebih dari 0.');
  }

  const discount = pointsToRedeem * POINT_VALUE_RUPIAH;

  const affected = await tx.$executeRaw`
    UPDATE users
    SET rizpoint = rizpoint - ${pointsToRedeem}
    WHERE id = ${userId} AND rizpoint >= ${pointsToRedeem}
  `;
  if (affected === 0) {
    throw new RizpointError('Saldo RizPoint tidak cukup.');
  }

  await tx.rizpointTransaction.create({
    data: {
      userId,
      orderId,
      type: 'redeem',
      amount: -pointsToRedeem, // negatif = pengurangan, biar riwayat gampang dijumlah
      description: `Tukar ${pointsToRedeem} RizPoint untuk diskon Rp${discount.toLocaleString('id-ID')}`,
    },
  });

  return { pointsRedeemed: pointsToRedeem, discount };
}

module.exports = { redeemPoints, RizpointError, POINT_VALUE_RUPIAH };
