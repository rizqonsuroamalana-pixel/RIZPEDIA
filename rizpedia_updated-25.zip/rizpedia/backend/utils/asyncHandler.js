// Membungkus async route handler supaya kalau ada error/reject promise,
// otomatis dilempar ke Express error handler (bukan bikin server crash).
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

module.exports = asyncHandler;
