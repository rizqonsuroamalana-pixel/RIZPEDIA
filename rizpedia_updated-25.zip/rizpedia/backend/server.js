require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('path');
const prisma = require('./db');

const authRoutes = require('./routes/auth');
const meRoutes = require('./routes/me');
const orderRoutes = require('./routes/orders');
const paymentRoutes = require('./routes/payments');
const topupRoutes = require('./routes/topup');
const voucherRoutes = require('./routes/vouchers');
const notificationRoutes = require('./routes/notifications');
const rizpointRoutes = require('./routes/rizpoint');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

// ===== 46. Security headers =====
// Helmet pasang sekumpulan header standar (X-Content-Type-Options, X-Frame-Options,
// Strict-Transport-Security saat HTTPS, dll) dengan pengaturan default yang aman.
app.use(helmet());

// ===== 51. Audit logging (request-level) =====
// Ini pencatatan tiap HTTP request masuk (siapa akses apa, kapan, status berapa) —
// pelengkap admin_logs (yang cuma mencatat AKSI admin spesifik). Kombinasi keduanya
// yang jadi jejak audit lengkap. 'combined' = format Apache log standar.
app.use(morgan('combined'));

// ===== 45. CORS restriction =====
// ALLOWED_ORIGINS di .env diisi daftar origin yang boleh akses API ini, dipisah koma,
// mis. "https://rizpedia.id,https://www.rizpedia.id". Kalau dikosongkan, sementara
// mengizinkan semua origin (supaya development tidak ribet) TAPI dicetak warning di
// log — WAJIB diisi sebelum production.
const allowedOrigins = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);
if (allowedOrigins.length === 0) {
  console.warn(
    '⚠️  ALLOWED_ORIGINS belum diisi di .env — CORS saat ini mengizinkan SEMUA origin. ' +
      'Isi sebelum deploy production, mis. ALLOWED_ORIGINS=https://rizpedia.id'
  );
}
app.use(
  cors({
    origin(origin, callback) {
      // origin kosong = request non-browser (curl, mobile app, webhook provider) -> izinkan.
      if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(new Error('Origin tidak diizinkan oleh kebijakan CORS.'));
    },
    credentials: true,
  })
);

// ===== 43. Rate limiting =====
// Limiter umum untuk semua endpoint /api — cegah 1 IP membanjiri server.
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 menit
  max: 300,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak request dari IP ini, coba lagi beberapa saat.' },
});
app.use('/api', globalLimiter);

// Limiter LEBIH KETAT khusus /api/auth — target: cegah brute-force login & spam register.
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan login/daftar, coba lagi dalam 15 menit.' },
});
app.use('/api/auth', authLimiter);

app.use(
  express.json({
    limit: '200kb', // batasi ukuran body — cegah payload raksasa jadi vektor DoS
    // Simpan raw body mentah — dibutuhkan utils/tripay.js untuk verifikasi
    // signature webhook (HMAC dihitung dari body ASLI, bukan hasil parse ulang).
    verify: (req, res, buf) => {
      req.rawBody = buf;
    },
  })
);

// Layani file frontend statis (desktop.html, mobile.html)
app.use(express.static(path.join(__dirname, '../frontend')));

// ================= AUTH & PROFIL =================
app.use('/api/auth', authRoutes);       // POST /api/auth/register, POST /api/auth/login
app.use('/api/me', meRoutes);           // GET  /api/me

// ================= ORDER, PEMBAYARAN, TOP UP =================
app.use('/api/orders', orderRoutes);     // POST /api/orders, GET /api/orders/:id
app.use('/api/payments', paymentRoutes); // POST /api/payments, POST /api/payments/webhook
app.use('/api/topup', topupRoutes);      // POST /api/topup

// ================= VOUCHER, NOTIFIKASI, RIZPOINT =================
app.use('/api/vouchers', voucherRoutes);           // POST /api/vouchers/validate, POST /api/vouchers/use
app.use('/api/notifications', notificationRoutes); // GET  /api/notifications
app.use('/api/rizpoint', rizpointRoutes);          // GET  /api/rizpoint

// ================= ADMIN (requireAuth + requireAdmin) =================
app.use('/api/admin', adminRoutes); // GET /api/admin/users, PATCH /api/admin/users/:id/role, GET /api/admin/logs

// ================= KATALOG GAME & LEADERBOARD (dari database) =================
// Bentuk ulang baris Product dari DB jadi format "denom" lama supaya frontend
// (desktop.html/mobile.html) yang sudah ada TIDAK perlu diubah dulu.
function toDenomShape(product) {
  const rawAmt = (product.providerProductId || '').split('-').slice(1).join('-').replace(/_/g, ' ');
  const amt = rawAmt && !Number.isNaN(Number(rawAmt)) ? Number(rawAmt) : product.name;
  const denom = { amt, price: Number(product.sellingPrice), productId: product.id };
  if (Number(product.providerPrice) > Number(product.sellingPrice)) {
    denom.old = Number(product.providerPrice);
  }
  if (product.description) denom.badge = product.description;
  return denom;
}

app.get('/api/games', async (req, res) => {
  try {
    const games = await prisma.game.findMany({
      where: { status: 'active' },
      include: { products: { where: { status: 'active' } } },
    });
    const result = {};
    for (const game of games) {
      const code = game.slug.toUpperCase().replace(/-/g, '_');
      result[code] = { unit: '', denoms: game.products.map(toDenomShape) };
    }
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Gagal mengambil data game dari database' });
  }
});

app.get('/api/games/:code', async (req, res) => {
  try {
    const code = req.params.code.toLowerCase().replace(/_/g, '-');
    const game = await prisma.game.findFirst({
      where: { OR: [{ slug: code }, { slug: req.params.code.toLowerCase() }] },
      include: { products: { where: { status: 'active' } } },
    });
    if (!game) {
      return res.status(404).json({ error: `Game dengan kode "${req.params.code}" tidak ditemukan` });
    }
    res.json({ unit: '', denoms: game.products.map(toDenomShape) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Gagal mengambil data game dari database' });
  }
});

// Samarkan nama customer supaya tidak bocor penuh di leaderboard publik.
// "Rizky Ananda" -> "Riz****" (nama depan saja, sisanya diganti tanda bintang tetap 4 karakter
// supaya panjang nama asli juga tidak ketebak dari jumlah bintangnya).
function maskName(name) {
  const firstName = (name || '').trim().split(/\s+/)[0] || 'Pengguna';
  const visible = firstName.slice(0, Math.min(3, firstName.length));
  return `${visible}****`;
}

// Leaderboard: total top up (paymentStatus = paid) per user, dari tabel orders.
// Dikelompokkan per userId (bukan customerName) supaya tidak kesplit kalau nama yang
// tersimpan di order beda-beda kapitalisasi/ejaan; nama asli tidak pernah dikirim ke client.
app.get('/api/leaderboard', async (req, res) => {
  try {
    const rows = await prisma.order.groupBy({
      by: ['userId'],
      where: { paymentStatus: 'paid', userId: { not: null } },
      _sum: { amount: true },
    });

    const userIds = rows.map((r) => r.userId);
    const users = await prisma.user.findMany({
      where: { id: { in: userIds } },
      select: { id: true, name: true },
    });
    const nameById = new Map(users.map((u) => [u.id, u.name]));

    const result = rows
      .map((r) => ({
        name: maskName(nameById.get(r.userId)),
        amount: Number(r._sum.amount || 0),
      }))
      .sort((a, b) => b.amount - a.amount);

    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Gagal mengambil leaderboard dari database' });
  }
});

// Arahkan root ke versi desktop
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/desktop.html'));
});

// ================= 404 & ERROR HANDLER =================
app.use('/api', (req, res) => {
  res.status(404).json({ error: `Endpoint ${req.method} ${req.originalUrl} tidak ditemukan.` });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error(err);
  const status = err.status || 500;
  // Error 4xx (validasi, auth, dsb) memang sengaja pesannya informatif untuk user.
  // Error 5xx di production TIDAK menampilkan detail asli (bisa bocorkan info internal/
  // struktur database) — cukup pesan generik; detail lengkapnya tetap ada di console.error di atas.
  const isServerError = status >= 500;
  const hideDetails = isServerError && process.env.NODE_ENV === 'production';
  res.status(status).json({ error: hideDetails ? 'Terjadi kesalahan pada server.' : err.message || 'Terjadi kesalahan pada server.' });
});

app.listen(PORT, () => {
  console.log(`Rizpedia backend jalan di http://localhost:${PORT}`);
  console.log(`  - Desktop : http://localhost:${PORT}/desktop.html`);
  console.log(`  - Mobile  : http://localhost:${PORT}/mobile.html`);
  console.log(`  - API     : http://localhost:${PORT}/api/games`);
});
