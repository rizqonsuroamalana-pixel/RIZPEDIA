// Prisma client singleton — di-require dari server.js dan module lain yang butuh akses DB.
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

module.exports = prisma;
