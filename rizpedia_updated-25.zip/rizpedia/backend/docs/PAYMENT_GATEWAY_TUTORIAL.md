# Tutorial: Mengisi Payment Gateway Sungguhan di Rizpedia

Dokumen ini panduan buat KAMU isi sendiri 2 titik placeholder di kode:
- `backend/routes/payments.js` → bikin transaksi & terima webhook
- (topup ke provider game itu bagian TERPISAH di `backend/utils/topup.js`, tidak dibahas di sini)

Alur lengkapnya (yang sudah jalan di kode vs yang masih placeholder):

```
User pilih produk          → SUDAH JALAN (POST /api/orders)
Backend membuat Order       → SUDAH JALAN
Backend membuat Payment     → SUDAH JALAN (tapi isinya masih dummy) ⟵ KAMU ISI DI SINI
Payment Gateway             → BELUM ADA, kamu sambungkan             ⟵ KAMU ISI DI SINI
User membayar                → tergantung gateway (halaman/QR dari mereka)
Gateway → Webhook Rizpedia  → endpoint-nya SUDAH ADA, tapi verifikasi masih dummy ⟵ KAMU ISI DI SINI
Verifikasi signature        → BELUM ADA signature asli                ⟵ KAMU ISI DI SINI
paymentStatus = PAID        → SUDAH JALAN otomatis setelah webhook valid
Topup ke Provider           → placeholder terpisah, lihat utils/topup.js
topupStatus = SUCCESS       → SUDAH JALAN otomatis
Notifikasi user             → SUDAH JALAN otomatis
```

Jadi cuma ada **3 titik** yang perlu kamu isi. Contoh di bawah pakai **Tripay** (paling umum dipakai situs top up Indonesia, ada mode Sandbox gratis buat testing). Kalau kamu pilih Midtrans/Xendit, pola & urutannya sama persis — cuma nama field & cara hitung signature-nya beda, sudah saya kasih catatan di tiap langkah.

---

## Langkah 0 — Daftar akun & ambil kredensial

1. Daftar di **tripay.co.id** → pilih mode **Sandbox** dulu buat testing (gratis, tidak perlu approval merchant).
2. Di dashboard Sandbox, catat 3 nilai ini:
   - `Merchant Code`
   - `API Key`
   - `Private Key`
3. Tambahkan channel pembayaran yang mau dipakai (QRIS, BRIVA, dll) — Tripay Sandbox biasanya sudah nyediain beberapa default.

> Kalau pakai **Midtrans**: yang kamu butuh cuma `Server Key` & `Client Key` dari dashboard Sandbox Midtrans.
> Kalau pakai **Xendit**: kamu butuh `Secret API Key` + `Callback Verification Token` dari dashboard.

---

## Langkah 1 — Isi kredensial ke `.env`

Buka `backend/.env`, tambahkan (kalau pakai Tripay):

```env
TRIPAY_MERCHANT_CODE=xxxxx
TRIPAY_API_KEY=xxxxx
TRIPAY_PRIVATE_KEY=xxxxx
TRIPAY_BASE_URL=https://tripay.co.id/api-sandbox
# kalau sudah live, ganti ke: https://tripay.co.id/api

# URL publik backend kamu (dipakai Tripay buat callback & redirect balik).
# Kalau masih testing di localhost, pakai ngrok (lihat Langkah 4).
APP_BASE_URL=https://xxxx.ngrok-free.app
```

Ganti `PAYMENT_PROVIDER=manual` yang sudah ada jadi:
```env
PAYMENT_PROVIDER=tripay
```

---

## Langkah 2 — Isi bagian "bikin transaksi" di `routes/payments.js`

Cari komentar ini di file `backend/routes/payments.js`:
```js
// ===== PLACEHOLDER — ganti dengan call API payment gateway sungguhan =====
const paymentReference = 'PAY-' + crypto.randomBytes(5).toString('hex').toUpperCase();
const expiredAt = new Date(Date.now() + PAYMENT_TIMEOUT_MINUTES * 60 * 1000);
// ===== akhir placeholder =====
```

Ganti seluruh blok itu jadi (contoh Tripay, pakai `merchant_ref` = order number kamu):

```js
// ===== Integrasi Tripay =====
const merchantRef = order.orderNumber;
const amount = Math.round(Number(order.amount));

// Tripay wajib signature: HMAC SHA256 dari (merchant_code + merchant_ref + amount)
const signature = crypto
  .createHmac('sha256', process.env.TRIPAY_PRIVATE_KEY)
  .update(process.env.TRIPAY_MERCHANT_CODE + merchantRef + amount)
  .digest('hex');

const tripayRes = await fetch(`${process.env.TRIPAY_BASE_URL}/transaction/create`, {
  method: 'POST',
  headers: {
    Authorization: `Bearer ${process.env.TRIPAY_API_KEY}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    method: paymentMethod,              // kode channel Tripay, mis. "QRIS", "BRIVA"
    merchant_ref: merchantRef,
    amount,
    customer_name: order.customerName,
    customer_email: order.customerEmail,
    order_items: [{ sku: order.productId, name: 'Top Up', price: amount, quantity: 1 }],
    callback_url: `${process.env.APP_BASE_URL}/api/payments/webhook`,
    return_url: `${process.env.APP_BASE_URL}/desktop.html`,
    expired_time: Math.floor(Date.now() / 1000) + PAYMENT_TIMEOUT_MINUTES * 60,
    signature,
  }),
});

const tripayData = await tripayRes.json();
if (!tripayData.success) {
  return res.status(502).json({ error: 'Gagal membuat transaksi di Tripay', detail: tripayData.message });
}

const paymentReference = tripayData.data.reference;      // simpan ini, dipakai buat cocokkan webhook nanti
const expiredAt = new Date(tripayData.data.expired_time * 1000);
const checkoutUrl = tripayData.data.checkout_url;         // link/QR buat user bayar
// ===== akhir integrasi Tripay =====
```

Lalu di bagian `res.status(201).json({...})` di bawahnya, tambahkan `checkoutUrl` supaya frontend bisa redirect/tampilkan QR:

```js
res.status(201).json({
  payment,
  checkoutUrl,   // <-- tambahkan ini
  instructions: `Selesaikan pembayaran sebelum ${expiredAt.toLocaleString('id-ID')}.`,
});
```

> **Midtrans**: endpoint-nya `POST https://api.sandbox.midtrans.com/v2/charge`, autentikasi pakai Basic Auth dari `Server Key` (bukan HMAC signature), dan responsnya kasih `redirect_url` (Snap) atau `va_numbers`.
> **Xendit**: endpoint `POST https://api.xendit.co/v2/invoices`, autentikasi Basic Auth dari `Secret Key`, responsnya kasih `invoice_url`.
> Pola kodenya tetap sama: siapkan body → `fetch()` ke API mereka → simpan `paymentReference` dari hasilnya → balikan URL/instruksi ke frontend.

---

## Langkah 3 — Isi verifikasi signature di webhook

Cari komentar ini di file yang sama:
```js
// TODO PRODUCTION: ganti verifikasi `x-webhook-secret` ini sesuai skema signature
// provider asli (mis. header X-Callback-Token untuk Xendit, signature key untuk Midtrans).
const secret = req.headers['x-webhook-secret'];
if (!process.env.PAYMENT_WEBHOOK_SECRET || secret !== process.env.PAYMENT_WEBHOOK_SECRET) {
  return res.status(401).json({ error: 'Webhook signature tidak valid.' });
}
```

Ganti jadi (contoh Tripay — signature-nya HMAC SHA256 dari **raw body**, dikirim di header `X-Callback-Signature`):

```js
const callbackSignature = req.headers['x-callback-signature'];
const expectedSignature = crypto
  .createHmac('sha256', process.env.TRIPAY_PRIVATE_KEY)
  .update(JSON.stringify(req.body))
  .digest('hex');

if (callbackSignature !== expectedSignature) {
  return res.status(401).json({ error: 'Webhook signature tidak valid.' });
}
```

Lalu sesuaikan pembacaan `paymentReference` & `status` dari body Tripay (field aslinya beda nama):
```js
const { reference: paymentReference, status: tripayStatus } = req.body || {};
// Tripay pakai: PAID, EXPIRED, FAILED, REFUND — petakan ke enum kita:
const statusMap = { PAID: 'paid', EXPIRED: 'expired', FAILED: 'failed' };
const normalizedStatus = statusMap[tripayStatus] || null;
```
(baris `normalizedStatus` yang lama di kode tinggal dihapus, ganti dengan mapping ini.)

> **Penting**: raw body harus PERSIS sama bytes-nya seperti yang dikirim Tripay untuk hitung HMAC. Kalau ternyata signature selalu mismatch, biasanya karena Express sudah re-serialize JSON (`JSON.stringify(req.body)` bisa beda urutan key dari body asli). Solusi paling aman: pakai raw body asli, bukan hasil parse ulang — tambahkan middleware `express.json({ verify: (req, res, buf) => { req.rawBody = buf; } })` di `server.js`, lalu di webhook pakai `req.rawBody` (bukan `JSON.stringify(req.body)`) untuk hitung HMAC.

> **Midtrans**: signature-nya `SHA512(order_id + status_code + gross_amount + ServerKey)`, dikirim di body (bukan header), field `signature_key`.
> **Xendit**: bukan HMAC, tapi header `X-Callback-Token` yang tinggal dicocokkan string-nya dengan token dari dashboard (mirip cara lama di kode kita, tapi nama header beda).

---

## Langkah 4 — Testing di localhost pakai ngrok

Karena payment gateway butuh URL publik buat kirim webhook (tidak bisa ke `localhost`), pakai **ngrok**:

1. Install & jalankan: `ngrok http 3000`
2. Ngrok kasih URL publik, mis. `https://a1b2c3.ngrok-free.app`
3. Isi itu ke `.env` → `APP_BASE_URL=https://a1b2c3.ngrok-free.app`
4. Di dashboard Tripay Sandbox, set **Callback URL** ke `https://a1b2c3.ngrok-free.app/api/payments/webhook`
5. Restart server (`npm start`), coba `POST /api/payments`, buka `checkoutUrl` yang dibalikin, selesaikan pembayaran dummy di Sandbox Tripay → cek apakah webhook masuk dan `paymentStatus` order berubah jadi `paid`.

---

## Checklist sebelum ganti ke mode production (uang asli)

- [ ] Ganti `TRIPAY_BASE_URL` dari `api-sandbox` ke `api` (atau setara di Midtrans/Xendit)
- [ ] Ganti semua kredensial ke yang versi production (bukan sandbox)
- [ ] `APP_BASE_URL` sudah pakai domain asli (bukan ngrok)
- [ ] Signature verification sudah dites benar-benar cocok (jangan pernah skip verifikasi ini di production — tanpa ini siapa saja bisa kirim webhook palsu dan "membayar gratis")
- [ ] Simpan `TRIPAY_PRIVATE_KEY`/`SERVER_KEY`/`SECRET_KEY` HANYA di `.env` server (jangan pernah taruh di kode frontend/HTML)

Kalau ada error spesifik pas isi kode ini (mis. respons API provider yang beda dari contoh, atau signature terus mismatch), tempel pesan errornya ke saya, saya bantu telusuri.
