// Seed data awal untuk production DB.
// Memigrasikan katalog lama di `backend/data/games.js` (object statis) ke tabel
// `games` + `products` yang baru, plus 1 akun admin default.
//
// Jalankan: npx prisma db seed   (lihat konfigurasi "prisma.seed" di package.json)

const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const OLD_GAMES = require('../data/games');

const prisma = new PrismaClient();

// Metadata tambahan yang dulu tidak ada di games.js (slug & nama tampilan & gambar),
// diambil dari struktur folder assets/games & konten frontend lama.
const GAME_META = {
  MLBB: { name: 'Mobile Legends', slug: 'mobile-legends', image: 'mlbb.jpg' },
  FF: { name: 'Free Fire', slug: 'free-fire', image: 'ff.jpg' },
  PUBG: { name: 'PUBG Mobile', slug: 'pubg-mobile', image: 'pubg.jpg' },
  GI: { name: 'Genshin Impact', slug: 'genshin-impact', image: 'gi.jpg' },
  VAL: { name: 'Valorant', slug: 'valorant', image: 'val.jpg' },
  RBX: { name: 'Roblox', slug: 'roblox', image: 'rbx.jpg' },
  GPL: { name: 'Google Play', slug: 'google-play', image: 'gpl.jpg' },
  STM: { name: 'Steam Wallet', slug: 'steam-wallet', image: 'stm.jpg' },
  TSL: { name: 'Telkomsel', slug: 'telkomsel', image: 'tsl.jpg' },
  PLN: { name: 'PLN Token', slug: 'pln-token', image: 'pln.jpg' },
  XL: { name: 'XL Axiata', slug: 'xl-axiata', image: 'xl.jpg' },
  SPT: { name: 'Spotify Premium', slug: 'spotify', image: 'spt.jpg' },
};

async function main() {
  console.log('Seeding database...');
  let unmappedCount = 0; // hitung produk yang providerProductId-nya masih kosong

  // 1. Admin default (ganti password ini segera setelah deploy pertama!)
  const adminPasswordHash = await bcrypt.hash(
    process.env.SEED_ADMIN_PASSWORD || 'ChangeMe123!',
    10
  );
  await prisma.user.upsert({
    where: { email: process.env.SEED_ADMIN_EMAIL || 'admin@rizpedia.id' },
    update: {},
    create: {
      name: 'Super Admin',
      email: process.env.SEED_ADMIN_EMAIL || 'admin@rizpedia.id',
      passwordHash: adminPasswordHash,
      role: 'admin',
    },
  });

  // 2. Games + Products dari data/games.js lama
  for (const [code, data] of Object.entries(OLD_GAMES)) {
    const meta = GAME_META[code] || {
      name: code,
      slug: code.toLowerCase(),
      image: null,
    };

    const game = await prisma.game.upsert({
      where: { slug: meta.slug },
      update: { name: meta.name, image: meta.image },
      create: {
        name: meta.name,
        slug: meta.slug,
        image: meta.image,
        status: 'active',
      },
    });

    for (const denom of data.denoms) {
      const label = `${denom.amt}${denom.unit || data.unit ? ' ' + (denom.unit || data.unit) : ''}`.trim();
      // Hanya dipakai kalau memang sudah diisi manual di data/games.js (lihat komentar di atas
      // file itu). TIDAK LAGI di-generate otomatis seperti "MLBB-172" — itu bukan ID asli
      // dari provider, cuma bikin ilusi produk sudah siap padahal belum bisa dipakai top up.
      const providerProductId = denom.providerProductId || null;
      if (!providerProductId) unmappedCount += 1;

      // Kalau providerProductId belum ada, jangan dijadikan kunci pencarian (banyak produk
      // bakal sama-sama null dan malah numpuk jadi 1 baris) — pakai nama produk sebagai kunci.
      const existing = await prisma.product.findFirst({
        where: providerProductId
          ? { gameId: game.id, providerProductId }
          : { gameId: game.id, providerProductId: null, name: label },
        select: { id: true },
      });

      const productData = {
        name: label,
        description: denom.badge || null,
        providerPrice: denom.old || denom.price,
        sellingPrice: denom.price,
        status: 'active',
      };

      if (existing) {
        await prisma.product.update({ where: { id: existing.id }, data: productData });
      } else {
        await prisma.product.create({
          data: { gameId: game.id, providerProductId, ...productData },
        });
      }
    }
    console.log(`  - ${meta.name}: ${data.denoms.length} produk`);
  }

  // 3. Voucher contoh (menggantikan generateVouchers() acak di localStorage)
  await prisma.voucher.upsert({
    where: { code: 'RIZWELCOME' },
    update: {},
    create: {
      code: 'RIZWELCOME',
      type: 'percentage',
      value: 10,
      minimumTransaction: 20000,
      maximumDiscount: 15000,
      usageLimit: 1000,
      status: 'active',
    },
  });

  console.log('Seeding selesai.');
  if (unmappedCount > 0) {
    console.log('');
    console.log(`⚠️  ${unmappedCount} produk BELUM punya providerProductId (masih null).`);
    console.log('    Top up untuk produk-produk itu akan DITOLAK otomatis oleh utils/topup.js');
    console.log('    sampai kamu isi providerProductId asli di backend/data/games.js lalu jalankan ulang `npm run seed`.');
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
