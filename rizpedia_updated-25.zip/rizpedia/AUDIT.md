# AUDIT PROJECT RIZPEDIA
Tanggal audit: 27 Agustus 2026

## 1. Struktur Project
```
rizpedia/
├── backend/
│   ├── data/
│   │   ├── games.js            # katalog game + harga (hardcoded JS object)
│   │   └── transactions.json   # "database" transaksi (array JSON, cuma dipakai leaderboard)
│   ├── server.js                # Express, 4 endpoint saja
│   └── package.json             # dependency: express, cors (tidak ada DB driver/ORM)
└── frontend/
    ├── desktop.html              # ~1700 baris: HTML + CSS + JS inline jadi satu file
    ├── mobile.html                # ~1600 baris: HTML + CSS + JS inline, LOGIKA DIDUPLIKASI dari desktop.html
    └── assets/                    # gambar game & banner
```
Tidak ada folder `migrations/`, `models/`, `controllers/`, `middlewares/`, `auth/`, `.env`, atau test. Ini murni prototipe desain, bukan aplikasi production.

## 2. Frontend vs Backend
- **Frontend**: 2 file HTML statis (desktop & mobile) berisi seluruh UI + seluruh *business logic* (auth, voucher, RizPoint, transaksi, leaderboard) dalam `<script>` inline. Tidak ada framework (React/Vue), tidak ada build step.
- **Backend**: Express minimal yang hanya (1) menyajikan file statis frontend, (2) expose data harga game, (3) menyimpan transaksi ke file JSON untuk keperluan leaderboard.
- **Masalah besar**: hampir semua logika inti (login, keranjang, checkout, voucher, poin, status pembayaran) berjalan **100% di browser** lewat `localStorage`, bukan di server. Ini tidak aman dan tidak bisa dipakai production (user bisa edit localStorage sendiri untuk dapat saldo/poin/voucher gratis, dan data hilang begitu ganti device/browser).

## 3. API yang Sudah Ada
| Endpoint | Fungsi | Catatan |
|---|---|---|
| `GET /api/games` | Semua data game & harga | Sumbernya `data/games.js`, statis |
| `GET /api/games/:code` | Data 1 game | idem |
| `POST /api/transactions` | Simpan `{name,email,amount}` ke JSON | Tidak ada validasi kepemilikan, tidak terhubung ke order asli, dipanggil "diam-diam" hanya untuk isi leaderboard |
| `GET /api/leaderboard` | Rekap top up per email | Dihitung dari file JSON |

Tidak ada endpoint untuk: auth/login, register, produk per game, checkout, create order, callback pembayaran, voucher, RizPoint, notifikasi, admin. Semua itu baru ada di sisi frontend sebagai simulasi.

## 4. Sistem Transaksi Saat Ini
- Order dibuat via `createPendingTransaction()` di JS **frontend**, disimpan ke `localStorage['rizpedia_transactions']`, dikelompokkan per email.
- Tombol **"Saya Sudah Bayar"** langsung mengubah status `pending → paid` di localStorage — **tidak ada verifikasi pembayaran sungguhan** (tidak ada payment gateway/callback dari provider apa pun; tidak ditemukan integrasi Midtrans/Xendit/Tripay/Digiflazz/dsb).
- Auto-cancel 5 menit dihitung di client (`setInterval` browser), bukan job/cron di server.
- `POST /api/transactions` ke backend hanya dipanggil **setelah** status di-set "paid" secara lokal, semata untuk mengisi leaderboard publik — bukan pencatat order yang sah.
- Tidak ada `order_number`, tidak ada relasi ke produk/game/provider, tidak ada status top up (proses ke provider game) — hanya status pembayaran versi mainan.

## 5. File Data JSON
- `backend/data/transactions.json`: array kosong `[]`, tanpa skema tetap, ditulis ulang penuh (`fs.writeFileSync`) setiap ada transaksi baru — rawan race condition kalau diakses bersamaan, dan hilang kalau file/disk direset (misalnya deploy ulang di banyak platform serverless).
- `backend/data/games.js`: bukan JSON, tapi modul JS yang di-`require` — cukup baik untuk prototipe, tapi tidak bisa diubah lewat admin panel, tidak punya histori harga, dan **didup dupelan sebagian** — `mobile.html` ternyata punya salinan hardcoded objek `GAMES` sendiri di dalam `<script>`-nya (baris ~730), terpisah dari `backend/data/games.js`. Jadi kalau harga diubah di backend, mobile bisa saja tidak sinkron kalau fetch API gagal (dipakai sebagai fallback), tapi ini tetap adalah data ganda yang berisiko drift.

## 6. Sistem Produk/Game
- Katalog: 12 game/layanan (MLBB, FF, PUBG, GI, VAL, RBX, GPL, STM, TSL, PLN, XL, SPT) dengan denominasi per game (`denoms[]`) berisi `amt`, `price`, kadang `old` (harga coret) dan `badge`.
- Tidak ada `provider_product_id` — artinya belum terhubung ke provider H2H manapun (mis. Digiflazz/VIP Reseller). Nominal & harga jual sepenuhnya manual di kode.
- Tidak ada kolom `status` aktif/nonaktif per produk, tidak ada `provider_price` vs `selling_price` terpisah (yang ada cuma satu `price` = harga jual).

## 7. Voucher
- Voucher **digenerate acak di browser** (`generateVouchers()`), bukan dari database. Setiap akun (dikenali dari `contact` di localStorage, bisa email sembarangan tanpa verifikasi) dapat "jatah kocok" 2x yang juga disimpan di localStorage.
- Klaim, wallet, dan pemakaian voucher (hangus sekali pakai) semuanya dihitung & disimpan di localStorage — **tidak ada tabel voucher di server**, tidak ada `usage_limit` global, tidak ada validasi lintas device, dan user teknisnya bisa reset jatah kocok cukup dengan clear localStorage atau ganti browser.
- Validasi minimum transaksi (`min`) sudah ada secara logic, tapi hanya divalidasi di client.

## 8. RizPoint
- Dihitung on-the-fly di frontend: `1 poin / Rp1.000` dari total transaksi berstatus `paid` di localStorage (`renderPoin()`). Tidak disimpan sebagai saldo permanen di server, tidak ada tabel `rizpoint_transactions`, dan fitur tukar poin eksplisit ditandai "sedang disiapkan" (belum ada).

## 9. Halaman Checkout
- Alur: pilih game → isi User ID/Zone ID (input tidak divalidasi ke provider) → pilih nominal → ringkasan + input kode voucher → pilih metode bayar (tampilan saja, tidak ada integrasi payment gateway nyata) → klik "Bayar Sekarang" → order tersimpan di localStorage sebagai `pending`.
- Tidak ada input yang disimpan sebagai `target_id`/`server_id`/`customer_name`/`customer_email` ke backend saat checkout — data customer baru dikirim ke backend belakangan, dan cuma `name+email+amount`, itu pun cuma untuk leaderboard.

## 10. Konfigurasi Environment
- **Tidak ada file `.env` atau `.env.example`**. `PORT` satu-satunya nilai yang dibaca dari `process.env` (`server.js:8`). Tidak ada konfigurasi untuk DB, secret JWT/session, kredensial payment gateway, atau kredensial provider game — karena memang belum ada satu pun dari itu yang diimplementasikan.

## 11. Kode yang Masih Mock/Demo (harus diganti untuk production)
- Auth: `openAuthModal`/submit login-register di `desktop.html` **tidak mengecek password ke server sama sekali** — asal isi form, langsung dianggap login sukses, nama akun ditebak dari string sebelum "@". Wajib diganti sistem auth sungguhan (hash password, sesi/JWT, endpoint server).
- Semua state penting (`rizpedia_user`, `rizpedia_transactions`, `rizpedia_voucher_state`, `rizpedia_notifications`) disimpan di `localStorage` — harus dipindah ke database + API terautentikasi.
- Status pembayaran "Saya Sudah Bayar" adalah tombol yang langsung mengubah status tanpa verifikasi — harus diganti callback/webhook dari payment gateway asli (Midtrans/Xendit/Tripay, dll).
- Leaderboard punya "bot" (`generateBotLeaderboard`) yang dicampur dengan pelanggan asli — perlu diputuskan apakah ini tetap dipakai sebagai elemen UI/marketing di production atau dihilangkan agar tidak menyesatkan.
- `POST /api/transactions` & `data/transactions.json` adalah pencatatan sementara yang harus digantikan skema `orders`/`payments` yang sebenarnya.

## 12. Fitur yang Masih Berguna & Harus Dipertahankan (bukan dihapus, tapi dimigrasikan)
- Desain UI desktop & mobile (HTML/CSS) — tetap dipakai, cukup disambungkan ke API baru.
- Struktur katalog game & skema denominasi (`amt/unit/price/old/badge`) — jadi basis kolom `products`.
- Alur UX voucher (kocok, klaim, wallet, sekali pakai, minimum transaksi) — logikanya bagus, tinggal dipindah perhitungan & penyimpanannya ke server.
- Alur RizPoint (1 poin/Rp1.000 dari transaksi lunas) — aturan bisnisnya dipakai lagi di tabel `rizpoint_transactions`.
- Auto-cancel order 5 menit — aturan bisnis valid, tinggal dieksekusi di server (bukan `setInterval` browser).
- FAQ, halaman bantuan, komponen notifikasi — tetap dipakai, sumber datanya nanti dari tabel `notifications`.

## Kesimpulan
Project ini adalah **prototipe UI/UX dengan simulasi logika di frontend**, bukan aplikasi yang siap production. Backend nyaris kosong (hanya harga statis). Untuk go-production dibutuhkan: database relasional sungguhan, sistem auth server-side, endpoint checkout/order/payment lengkap, integrasi payment gateway & provider top up asli, serta migrasi voucher/RizPoint/notifikasi dari localStorage ke server. Tidak ada fitur yang perlu dihapus — semua alur UX yang ada akan dipertahankan, hanya "otak"-nya dipindah dari browser ke backend + database.

**Lanjutan berikutnya**: bagian **2. DATABASE** pada dokumen ini dikerjakan di folder `backend/prisma/` (lihat `schema.prisma`, `seed.js`, dan `README.md` yang sudah diperbarui).
