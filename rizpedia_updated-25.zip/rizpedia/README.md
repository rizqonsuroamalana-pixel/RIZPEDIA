# Rizpedia

Prototipe desain & data harga untuk website top up voucher game "Rizpedia" (terinspirasi Takapedia).

## Struktur folder

```
rizpedia/
├── backend/
│   ├── data/
│   │   └── games.js       # Data game & harga (nominal, harga, badge flash sale/special)
│   ├── server.js          # Server Express + API harga
│   └── package.json
└── frontend/
    ├── desktop.html       # Desain versi desktop
    └── mobile.html        # Desain versi mobile (frame ponsel)
```

Setiap desain (desktop & mobile) ada di file HTML terpisah, dan keduanya mengambil data harga dari backend yang sama lewat API — jadi kalau harga diubah, cukup ubah satu file (`backend/data/games.js`), otomatis ikut berubah di kedua tampilan.

## Status project

- `AUDIT.md` — hasil audit menyeluruh project (frontend, backend, API, transaksi, voucher, RizPoint, checkout, env, kode mock yang perlu diganti).
- Database production sudah memakai **PostgreSQL + Prisma** (lihat `backend/prisma/schema.prisma`). File `backend/data/games.js` & `backend/data/transactions.json` versi lama masih ada sebagai referensi/sumber migrasi, tapi backend sekarang membaca dari database, bukan dari file itu lagi.

## Cara menjalankan (production-ready, dengan PostgreSQL)

1. Siapkan database PostgreSQL (lokal atau layanan seperti Supabase/Railway/RDS), lalu masuk ke folder backend:
   ```
   cd backend
   cp .env.example .env
   ```
   Isi `DATABASE_URL` di `.env` dengan connection string PostgreSQL kamu.
   Isi juga `ALLOWED_ORIGINS` dengan domain frontend kamu (pisahkan koma kalau lebih dari satu),
   dan set `NODE_ENV=production` sebelum deploy sungguhan (lihat bagian Security di bawah).

2. Install dependency:
   ```
   npm install
   ```

3. Jalankan migration (membuat semua tabel: users, games, products, orders, payments, vouchers, voucher_usage, rizpoint_transactions, notifications, admin_logs):
   ```
   npm run prisma:migrate
   ```

4. Isi data awal (seed): memigrasikan katalog `data/games.js` lama ke tabel `games`+`products`, membuat 1 akun admin, dan 1 voucher contoh:
   ```
   npm run seed
   ```

5. Jalankan server:
   ```
   npm start
   ```

6. Buka di browser:
   - Desktop: http://localhost:3000/desktop.html
   - Mobile: http://localhost:3000/mobile.html
   - API harga (dari database): http://localhost:3000/api/games

Perintah lain yang berguna: `npm run prisma:studio` (GUI untuk lihat/edit isi database).

## API

### Katalog & Publik
| Endpoint | Keterangan |
|---|---|
| `GET /api/games` | Semua data game & harga (dari tabel `games`+`products`) |
| `GET /api/games/:code` | Data satu game berdasarkan slug, mis. `/api/games/mobile-legends` |
| `GET /api/leaderboard` | Rekap top up per user dari tabel `orders` (`payment_status = paid`) |

### Auth & Profil
| Endpoint | Keterangan |
|---|---|
| `POST /api/auth/register` | Daftar akun baru — body `{ name, email, password }`, balikan `{ token, user }` |
| `POST /api/auth/login` | Login — body `{ email, password }`, balikan `{ token, user }` |
| `GET /api/me` | Profil user yang sedang login (butuh header `Authorization: Bearer <token>`) |

### Order, Pembayaran, Top Up
| Endpoint | Keterangan |
|---|---|
| `POST /api/orders` | Buat order baru — body `{ productId, targetId, serverId?, voucherCode? }` |
| `GET /api/orders/:id` | Detail 1 order (khusus pemilik order / admin) |
| `POST /api/payments` | Mulai pembayaran untuk sebuah order — body `{ orderId, paymentMethod }` (placeholder, lihat TODO di `routes/payments.js` untuk sambung ke Midtrans/Xendit/Tripay) |
| `POST /api/payments/webhook` | Callback dari payment gateway — divalidasi via header `x-webhook-secret` |
| `POST /api/topup` | Trigger/retry/cek-status proses top up ke provider game — body `{ orderId }`. Sudah terintegrasi Digiflazz sungguhan (`H2H_PROVIDER=digiflazz` di `.env`), mode `manual` (default) untuk development tanpa akun Digiflazz |

### Voucher, Notifikasi, RizPoint
| Endpoint | Keterangan |
|---|---|
| `POST /api/vouchers/validate` | Cek voucher tanpa memakainya — body `{ code, amount }` |
| `POST /api/vouchers/use` | Pakai voucher untuk order yang sudah dibuat (belum dibayar) — body `{ code, orderId }` |
| `GET /api/notifications` | 50 notifikasi terbaru milik user login |
| `GET /api/rizpoint` | Saldo & riwayat RizPoint milik user login |
| `POST /api/rizpoint/redeem` | Tukar RizPoint jadi diskon untuk order yang belum dibayar — body `{ orderId, points }` (1 RizPoint = Rp1 diskon, lihat `utils/rizpoint.js`) |

### Admin (butuh role `admin`, bukan cuma login)
| Endpoint | Keterangan |
|---|---|
| `GET /api/admin/dashboard` | Ringkasan angka: total user, total order, revenue, order hari ini, payment pending, topup belum selesai |
| `GET /api/admin/games` | Daftar semua game (termasuk yang nonaktif) |
| `POST /api/admin/games` | Buat game baru — `{ name, slug, image? }` |
| `PATCH /api/admin/games/:id` | Update game / ubah status aktif-nonaktif |
| `GET /api/admin/products?gameId=` | Daftar produk (opsional filter per game) |
| `POST /api/admin/products` | Buat produk baru — `{ gameId, providerProductId?, name, description?, providerPrice?, sellingPrice }` |
| `PATCH /api/admin/products/:id` | Update produk (nama, deskripsi, harga, status) — **kecuali** `providerProductId`, lihat 2 baris di bawah |
| `GET /api/admin/digiflazz/price-list?search=&brand=` | Cari SKU asli dari katalog Digiflazz akun kamu |
| `PATCH /api/admin/products/:id/provider-mapping` | Pasang `providerProductId` — divalidasi dulu ke katalog Digiflazz asli (SKU harus ada & aktif), harga modal ikut disinkronkan |
| `GET /api/admin/vouchers` | Daftar semua voucher |
| `POST /api/admin/vouchers` | Buat voucher baru |
| `PATCH /api/admin/vouchers/:id` | Update voucher (nilai, kuota, tanggal expired, status) |
| `GET /api/admin/orders?paymentStatus=&topupStatus=&search=` | Daftar & cari order |
| `PATCH /api/admin/orders/:id` | Override manual `topupStatus`/`failureReason`/`paymentStatus` (kecuali `paid` — lihat endpoint khusus di bawah) |
| `POST /api/admin/orders/:id/mark-paid` | **Satu-satunya** cara admin menandai order lunas manual — wajib `{ reason }` (≥10 karakter), otomatis jalankan efek yang sama seperti webhook (poin, notifikasi, trigger topup) |
| `GET /api/admin/payments?status=` | Monitoring semua transaksi pembayaran |
| `GET /api/admin/topups?topupStatus=` | Monitoring top up — default nampilin yang belum `success` |
| `GET /api/admin/users` | Daftar semua user |
| `PATCH /api/admin/users/:id/role` | Ubah role user — body `{ role: 'admin' \| 'customer' }` |
| `GET /api/admin/logs` | Riwayat aksi admin (tabel `admin_logs`) |

Semua endpoint di atas (kecuali katalog publik & webhook) butuh header:
```
Authorization: Bearer <token dari /api/auth/login atau /api/auth/register>
```

Payment gateway (Tripay) dan provider top up (Digiflazz) sudah terintegrasi sungguhan — tinggal isi kredensial masing-masing di `.env` dan ganti `PAYMENT_PROVIDER`/`H2H_PROVIDER` dari `manual` ke `tripay`/`digiflazz`. Sebelum itu diisi, semuanya tetap jalan di mode dummy supaya development/testing UI tidak terhambat.

## Mengubah harga

Sekarang harga dikelola lewat database (tabel `products`), bukan lagi lewat edit file. Untuk penyesuaian awal / bulk import, tetap bisa edit `backend/data/games.js` lalu jalankan ulang `npm run seed` (upsert, aman dijalankan berulang).
